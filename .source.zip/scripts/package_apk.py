#!/usr/bin/env python3
"""Use app-version.txt as the only source of the exported APK version."""
import hashlib
import pathlib
import re
import shutil
root = pathlib.Path(__file__).resolve().parents[1]
version = (root / 'app-version.txt').read_text().strip()
if not re.fullmatch(r'\d+\.\d+\.\d+', version):
    raise SystemExit('Invalid app-version.txt')
source = root / 'app/build/outputs/apk/release/app-release.apk'
if not source.is_file():
    raise SystemExit('Run assembleRelease first; signed release APK not found')
dest = root / 'dist'
dest.mkdir(exist_ok=True)
output = dest / f'tv2u-image tools-v{version}.apk'
shutil.copyfile(source, output)
checksum = hashlib.sha256(output.read_bytes()).hexdigest()
(output.with_suffix('.apk.sha256')).write_text(f'{checksum}  {output.name}\n')
print(output.name)
