#!/usr/bin/env python3
"""Prevent an old six-button source ZIP being built under a new version name."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/com/tv2u/imagetools/MainActivity.java').read_text()
assert (root/'editor-layout.txt').read_text().strip()=='TV2U-EDITOR-R8', 'Wrong editor layout'
for marker in ['LAYOUT_ID="TV2U-EDITOR-R8"','floatingTools','floatingActions','FrameLayout workspace','"Arrow"','"Upload"','"Search"','"Print"','"Copy"','"Save"','"Close"','"Straighten"','"Perspective"']:
    if marker not in main:
        raise SystemExit('Wrong or incomplete TV2U Editor R8 source: missing '+marker)
if 'for(String[] names:new String[][]' in main:
    raise SystemExit('Old six-button layout found. Upload the complete latest package.')
assert (root/'app/src/main/java/com/tv2u/imagetools/PerspectiveWarp.java').is_file()
assert 'minSdk 26' in (root/'app/build.gradle').read_text()
print('Verified TV2U-EDITOR-R8: TV2U items + Rotate/Straighten/Perspective Crop, Android 8+')

# Regression guard: XML attribute is API 27, while Java appearance flag is API 26.
base_theme=(root/'app/src/main/res/values/styles.xml').read_text()
assert 'android:windowLightNavigationBar' not in base_theme, 'API-27 navigation attribute must not be in base API-26 resources'
assert 'SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR' in main, 'Keep the white navigation bar readable on Android 8.0'
print('Verified Android 8.0 navigation theme compatibility')

for marker in ['root.addView(bottom,new LinearLayout.LayoutParams(-1,dp(40)))','place(floatingTools,toolsWidth,height,width-toolsWidth,0)','setText("")']:
    assert marker in main, 'Wrong toolbar layout: '+marker
assert 'workspace.addView(bottom' not in main
print('Verified bottom action dock and flush-right icon-only toolbar')
