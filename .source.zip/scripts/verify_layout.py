#!/usr/bin/env python3
"""Prevent an old six-button source ZIP being built under a new version name."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/com/tv2u/imagetools/MainActivity.java').read_text()
assert (root/'editor-layout.txt').read_text().strip()=='LIGHTSHOT-L6', 'Wrong editor layout'
for marker in ['LAYOUT_ID="LIGHTSHOT-L6"','floatingTools','floatingActions','FrameLayout workspace','"Arrow"','"Upload"','"Search"','"Print"','"Copy"','"Save"','"Close"','"Straighten"','"Perspective"']:
    if marker not in main:
        raise SystemExit('Wrong or incomplete Lightshot L6 source: missing '+marker)
if 'for(String[] names:new String[][]' in main:
    raise SystemExit('Old six-button layout found. Upload the complete latest package.')
assert (root/'app/src/main/java/com/tv2u/imagetools/PerspectiveWarp.java').is_file()
assert 'minSdk 26' in (root/'app/build.gradle').read_text()
print('Verified LIGHTSHOT-L6: Lightshot items + Rotate/Straighten/Perspective Crop, Android 8+')
