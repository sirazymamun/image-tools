#!/usr/bin/env python3
"""Prevent an old six-button source ZIP being built under a new version name."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/com/tv2u/imagetools/MainActivity.java').read_text()
assert (root/'editor-layout.txt').read_text().strip()=='TV2U-EDITOR-R14', 'Wrong editor layout'
for marker in ['LAYOUT_ID="TV2U-EDITOR-R14"','floatingTools','floatingActions','FrameLayout workspace','"Arrow"','"Upload"','"Search"','"Print"','"Copy"','"Save"','"Close"','"Straighten"','"Perspective"']:
    if marker not in main:
        raise SystemExit('Wrong or incomplete TV2U Editor R14 source: missing '+marker)
if 'for(String[] names:new String[][]' in main:
    raise SystemExit('Old six-button layout found. Upload the complete latest package.')
assert (root/'app/src/main/java/com/tv2u/imagetools/PerspectiveWarp.java').is_file()
assert 'minSdk 26' in (root/'app/build.gradle').read_text()
print('Verified TV2U-EDITOR-R14: TV2U items + Rotate/Straighten/Perspective Crop, Android 8+')

# Regression guard: XML attribute is API 27, while Java appearance flag is API 26.
base_theme=(root/'app/src/main/res/values/styles.xml').read_text()
assert 'android:windowLightNavigationBar' not in base_theme, 'API-27 navigation attribute must not be in base API-26 resources'
assert 'SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR' in main, 'Keep the light navigation bar readable on Android 8.0'
print('Verified Android 8.0 navigation theme compatibility')

for marker in ['root.addView(bottom,new LinearLayout.LayoutParams(-1,dp(40)))','place(floatingTools,toolsWidth,height,width-toolsWidth,0)','setText("")']:
    assert marker in main, 'Wrong toolbar layout: '+marker
assert 'workspace.addView(bottom' not in main
print('Verified bottom action dock and flush-right icon-only toolbar')

editor=(root/'app/src/main/java/com/tv2u/imagetools/EditorView.java').read_text()
for marker in ['void updateViewport()','void navigate(']:
    if marker=='void navigate(': marker='boolean navigate('
    assert marker in editor, 'Missing fill/zoom viewport: '+marker
assert 'root.addView(options)' not in main and 'root.addView(anglePanel)' not in main
print('Verified fill viewport, two-finger navigation and popup controls')

for name in ['TextLayer.java','ToolbarSkin.java']:
    assert (root/'app/src/main/java/com/tv2u/imagetools'/name).is_file(), 'Missing '+name
for marker in ['sizeButton=actionButton("Size"','void selectText(TextLayer','void changeSize(boolean text']:
    assert marker in main, 'Missing size/text fix: '+marker
print('Verified visible size controls, editable text and metallic toolbar skin')

assert 'float minimumZoom()' in editor and 'void fitImage()' in editor
for marker in ['zoomOut=actionButton("Zoom out"','zoomFit=actionButton("Fit image"','zoomIn=actionButton("Zoom in"']:
    assert marker in main, 'Missing perspective zoom control: '+marker
print('Verified selection-mode fit/pinch range and explicit zoom controls')

assert 'String tool="Move"' in editor and 'pendingStrokes' in editor
assert 'moveButton=actionButton("Move image"' in main
assert 'editor.commitBatch=this::commitDrawing' in main
assert 'void handleImageIntent(Intent intent)' in main
import xml.etree.ElementTree as ET
android='{http://schemas.android.com/apk/res/android}'
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
filters=manifest.findall('./application/activity/intent-filter')
view_filters=[f for f in filters if any(a.get(android+'name')=='android.intent.action.VIEW' for a in f.findall('action'))]
assert any(any(d.get(android+'mimeType')=='image/*' for d in f.findall('data')) and {'content','file'}.issubset({d.get(android+'scheme') for d in f.findall('data')}) and any(c.get(android+'name')=='android.intent.category.DEFAULT' for c in f.findall('category')) for f in view_filters), 'Missing Open with image filter'
print('Verified Move default, Apply/Cancel drawing preview and Open with manifest')

for marker in ['"Blur"','"Unblur"']:
    assert marker in main, 'Missing restored tool: '+marker
assert 'boolean freeformTouch(' in editor and 'lassoPath' in editor
document=(root/'app/src/main/java/com/tv2u/imagetools/EditDocument.java').read_text()
assert 'static Op freeform(' in document and 'maskCanvas.drawPath(op.path,p)' in document
print('Verified free-form Blur/Unblur selection and path mask renderer')

assert (root/'app/src/main/java/com/tv2u/imagetools/CompactDialog.java').is_file()
assert 'CompactDialog.Builder popup()' in main and 'new AlertDialog.Builder(this)' not in main
print('Verified shared compact bottom popup builder and centered action footer')
