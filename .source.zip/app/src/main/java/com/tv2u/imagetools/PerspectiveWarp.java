package com.tv2u.imagetools;
import android.graphics.*;

/** Four ordered corners (TL,TR,BR,BL) mapped onto a straight rectangle. */
final class PerspectiveWarp {
 static float distance(float[] q,int a,int b){return (float)Math.hypot(q[a*2]-q[b*2],q[a*2+1]-q[b*2+1]);}
 static boolean valid(float[] q){
  if(q==null||q.length!=8)return false;for(float f:q)if(Float.isNaN(f)||Float.isInfinite(f))return false;
  float sign=0;for(int i=0;i<4;i++){int j=(i+1)%4,k=(i+2)%4;if(distance(q,i,j)<2)return false;float cross=(q[j*2]-q[i*2])*(q[k*2+1]-q[j*2+1])-(q[j*2+1]-q[i*2+1])*(q[k*2]-q[j*2]);if(Math.abs(cross)<1)return false;if(sign==0)sign=cross;else if(sign*cross<=0)return false;}return true;
 }
 static int[] outputSize(float[] q){if(!valid(q))throw new IllegalArgumentException("Four corners must form a convex area");float w=Math.max(distance(q,0,1),distance(q,3,2)),h=Math.max(distance(q,0,3),distance(q,1,2));float ratio=Math.min(1f,1920f/Math.max(w,h));return new int[]{Math.max(2,Math.round(w*ratio)),Math.max(2,Math.round(h*ratio))};}
 static Bitmap warp(Bitmap source,float[] q){int[] size=outputSize(q);float[] dst={0,0,size[0],0,size[0],size[1],0,size[1]};Matrix m=new Matrix();if(!m.setPolyToPoly(q,0,dst,0,4))throw new IllegalArgumentException("Cannot straighten these corners");Bitmap out=Bitmap.createBitmap(size[0],size[1],Bitmap.Config.ARGB_8888);new Canvas(out).drawBitmap(source,m,new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG));return out;}
}
