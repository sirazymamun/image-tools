package com.tv2u.imagetools;
import android.graphics.*;
import java.util.*;
/** Immutable command history: no bitmap encoding, snapshots or disk I/O on UI. */
final class EditDocument {
 static final class Op {
  final String type,text; final Path path; final Rect rect; final float x,y,size,angle; final int color;
  Op(String t,Path p,Rect r,String s,float x,float y,float z,int c,float a){type=t;path=p==null?null:new Path(p);rect=r==null?null:new Rect(r);text=s;this.x=x;this.y=y;size=z;color=c;angle=a;}
  static Op region(String t,Rect r){return new Op(t,null,r,null,0,0,0,0,0);}
  static Op pen(Path p,float z,int c){return new Op("Pen",p,null,null,0,0,z,c,0);}
  static Op text(String s,float x,float y,float z,int c){return new Op("Text",null,null,s,x,y,z,c,0);}
  static Op rotate(float a){return new Op("Rotate",null,null,null,0,0,0,0,a);}
 }
 final Bitmap source,sourceBlur; final List<Op> ops; final int cursor;
 EditDocument(Bitmap b){this(b,BlurEngine.blur(b),Collections.emptyList(),0);}
 EditDocument(Bitmap b,Bitmap soft,List<Op> list,int n){source=b;sourceBlur=soft;ops=Collections.unmodifiableList(new ArrayList<>(list));cursor=n;}
 EditDocument add(Op op){ArrayList<Op> a=new ArrayList<>(ops.subList(0,cursor));a.add(op);return new EditDocument(source,sourceBlur,a,a.size());}
 EditDocument undo(){return new EditDocument(source,sourceBlur,ops,Math.max(0,cursor-1));}
 EditDocument redo(){return new EditDocument(source,sourceBlur,ops,Math.min(ops.size(),cursor+1));}
 static Bitmap blank(Bitmap b){return Bitmap.createBitmap(b.getWidth(),b.getHeight(),Bitmap.Config.ARGB_8888);}
 static Bitmap rotate(Bitmap b,float a){Matrix m=new Matrix();m.postRotate(a);return Bitmap.createBitmap(b,0,0,b.getWidth(),b.getHeight(),m,true);}
 static Bitmap cut(Bitmap b,Rect r){return Bitmap.createBitmap(b,r.left,r.top,r.width(),r.height());}
 static void release(Bitmap b,Bitmap next,Bitmap original){if(b!=next&&b!=original&&!b.isRecycled())b.recycle();}
 Bitmap render(){
  Bitmap base=source,soft=sourceBlur,mask=blank(source),ink=blank(source);
  try{
   for(int i=0;i<cursor;i++){
    Op op=ops.get(i);
    if(op.type.equals("Crop")||op.type.equals("Rotate")){
     Bitmap a,b,c,d;
     if(op.type.equals("Crop")){a=cut(base,op.rect);b=cut(soft,op.rect);c=cut(mask,op.rect);d=cut(ink,op.rect);}
     else{a=rotate(base,op.angle);b=rotate(soft,op.angle);c=rotate(mask,op.angle);d=rotate(ink,op.angle);}
     release(base,a,source);release(soft,b,sourceBlur);if(c!=mask)mask.recycle();if(d!=ink)ink.recycle();base=a;soft=b;
     mask=c.copy(Bitmap.Config.ARGB_8888,true);ink=d.copy(Bitmap.Config.ARGB_8888,true);c.recycle();d.recycle();
    }else if(op.type.equals("Blur")||op.type.equals("Unblur")){
     Paint p=new Paint();p.setColor(Color.WHITE);if(op.type.equals("Unblur"))p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));new Canvas(mask).drawRect(op.rect,p);
    }else{
     Canvas c=new Canvas(ink);Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(op.color);
     if(op.type.equals("Pen")){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(op.size);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);c.drawPath(op.path,p);}
     else{p.setTextSize(op.size);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));float y=op.y;for(String line:op.text.split("\n",-1)){c.drawText(line,op.x,y,p);y+=op.size*1.25f;}}
    }
   }
   Bitmap output=base.copy(Bitmap.Config.ARGB_8888,true),patch=soft.copy(Bitmap.Config.ARGB_8888,true);
   Paint p=new Paint();p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));new Canvas(patch).drawBitmap(mask,0,0,p);
   Canvas c=new Canvas(output);c.drawBitmap(patch,0,0,null);c.drawBitmap(ink,0,0,null);patch.recycle();return output;
  }finally{mask.recycle();ink.recycle();release(base,source,source);release(soft,sourceBlur,sourceBlur);}
 }
}
