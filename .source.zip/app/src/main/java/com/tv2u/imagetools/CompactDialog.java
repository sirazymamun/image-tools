package com.tv2u.imagetools;

import android.app.*;
import android.content.*;
import android.graphics.Rect;
import android.graphics.drawable.*;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.util.function.Supplier;

/** Compact app-owned popup anchored above the editor's confirmation/footer row. */
final class CompactDialog {
 static int dp(Context context,float value){return Math.round(value*context.getResources().getDisplayMetrics().density);}
 static final class Builder extends AlertDialog.Builder {
  final Activity activity;final Supplier<View> anchor;CharSequence title;
  Builder(Activity activity,Supplier<View> anchor){super(activity);this.activity=activity;this.anchor=anchor;}
  @Override public Builder setTitle(CharSequence title){this.title=title;super.setTitle(title);return this;}
  @Override public Builder setItems(CharSequence[] items,DialogInterface.OnClickListener listener){
   super.setAdapter(new ArrayAdapter<CharSequence>(activity,android.R.layout.simple_list_item_1,items){
    @Override public View getView(int position,View convert,ViewGroup parent){TextView row=(TextView)super.getView(position,convert,parent);row.setTextSize(14);row.setTextColor(0xff25313c);row.setMinHeight(dp(activity,36));row.setMinimumHeight(dp(activity,36));row.setPadding(dp(activity,12),dp(activity,4),dp(activity,12),dp(activity,4));row.setIncludeFontPadding(false);row.setLineSpacing(0,1);row.setSingleLine(false);row.setMaxLines(3);row.setEllipsize(TextUtils.TruncateAt.END);row.setLayoutParams(new AbsListView.LayoutParams(-1,-2));return row;}
   },listener);super.setNegativeButton("Cancel",null);return this;
  }
  @Override public Builder setView(View content){ScrollView scroll=new ScrollView(activity);scroll.setFillViewport(false);scroll.setPadding(0,0,0,0);scroll.addView(content,new ScrollView.LayoutParams(-1,-2));super.setView(scroll);return this;}
  @Override public AlertDialog show(){AlertDialog dialog=super.create();dialog.show();compact(dialog,title);new Positioner(activity,dialog,anchor).start();return dialog;}
 }
 static View named(AlertDialog dialog,String name){int id=dialog.getContext().getResources().getIdentifier(name,"id","android");return id==0?null:dialog.findViewById(id);}
 static View panel(AlertDialog dialog){View content=dialog.findViewById(android.R.id.content);if(content instanceof ViewGroup&&((ViewGroup)content).getChildCount()>0)return ((ViewGroup)content).getChildAt(0);return dialog.getWindow().getDecorView();}
 static TextView titleView(View view,CharSequence title){if(view instanceof TextView&&!(view instanceof Button)&&title!=null&&title.toString().contentEquals(((TextView)view).getText()))return (TextView)view;if(view instanceof ViewGroup){ViewGroup group=(ViewGroup)view;for(int i=0;i<group.getChildCount();i++){TextView result=titleView(group.getChildAt(i),title);if(result!=null)return result;}}return null;}
 static void trim(View view,Context context){view.setScrollIndicators(0);if(view instanceof Space){view.setVisibility(View.GONE);return;}if(view instanceof ViewGroup&&!(view instanceof ListView)){view.setMinimumHeight(0);view.setPadding(Math.min(view.getPaddingLeft(),dp(context,12)),Math.min(view.getPaddingTop(),dp(context,2)),Math.min(view.getPaddingRight(),dp(context,12)),Math.min(view.getPaddingBottom(),dp(context,2)));ViewGroup.LayoutParams lp=view.getLayoutParams();if(lp!=null){lp.height=ViewGroup.LayoutParams.WRAP_CONTENT;if(lp instanceof LinearLayout.LayoutParams&&view.getParent() instanceof LinearLayout&&((LinearLayout)view.getParent()).getOrientation()==LinearLayout.VERTICAL)((LinearLayout.LayoutParams)lp).weight=0;view.setLayoutParams(lp);}ViewGroup group=(ViewGroup)view;for(int i=0;i<group.getChildCount();i++)trim(group.getChildAt(i),context);}}
 static void compact(AlertDialog dialog,CharSequence caption){Context context=dialog.getContext();Window window=dialog.getWindow();if(window==null)return;window.setBackgroundDrawableResource(android.R.color.transparent);window.getDecorView().setPadding(0,0,0,0);window.setDimAmount(.12f);window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
  View panel=panel(dialog);trim(panel,context);GradientDrawable background=new GradientDrawable();background.setColor(0xffe7e9ec);background.setCornerRadius(dp(context,5));background.setStroke(dp(context,1),0xffaab1b8);panel.setBackground(background);panel.setPadding(0,dp(context,4),0,dp(context,2));
  TextView title=titleView(panel,caption);if(title!=null){title.setTextSize(17);title.setTextColor(0xff25313c);title.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.NORMAL);title.setMinHeight(0);title.setIncludeFontPadding(false);title.setPadding(0,0,0,0);title.setLineSpacing(0,1);if(title.getParent() instanceof View){View top=(View)title.getParent();top.setMinimumHeight(0);top.setPadding(dp(context,12),dp(context,5),dp(context,12),dp(context,3));}}
  TextView message=dialog.findViewById(android.R.id.message);if(message!=null){message.setTextSize(14);message.setMinHeight(0);message.setIncludeFontPadding(false);message.setLineSpacing(0,1);message.setPadding(dp(context,12),dp(context,4),dp(context,12),dp(context,4));}
  ListView list=dialog.getListView();if(list!=null){list.setPadding(0,0,0,0);list.setDivider(new ColorDrawable(0xffcbd0d5));list.setDividerHeight(dp(context,1));}
  List<Button> actions=new ArrayList<>();for(int which:new int[]{DialogInterface.BUTTON_NEGATIVE,DialogInterface.BUTTON_NEUTRAL,DialogInterface.BUTTON_POSITIVE}){Button button=dialog.getButton(which);if(button!=null&&button.getVisibility()==View.VISIBLE)actions.add(button);}
  View rawPanel=actions.isEmpty()?null:(View)actions.get(0).getParent();if(rawPanel instanceof LinearLayout&&!actions.isEmpty()){
   LinearLayout footer=(LinearLayout)rawPanel;for(Button button:actions){if(button.getParent() instanceof ViewGroup)((ViewGroup)button.getParent()).removeView(button);}footer.removeAllViews();footer.setOrientation(LinearLayout.HORIZONTAL);footer.setGravity(Gravity.CENTER);footer.setMinimumHeight(0);footer.setPadding(dp(context,8),dp(context,2),dp(context,8),dp(context,2));ViewGroup.LayoutParams lp=footer.getLayoutParams();lp.height=ViewGroup.LayoutParams.WRAP_CONTENT;footer.setLayoutParams(lp);
   for(Button button:actions){button.setAllCaps(false);button.setTextColor(0xffc65100);button.setTextSize(14);button.setMinHeight(0);button.setMinimumHeight(0);button.setMinWidth(dp(context,60));button.setMinimumWidth(dp(context,60));button.setPadding(dp(context,10),0,dp(context,10),0);button.setGravity(Gravity.CENTER);button.setIncludeFontPadding(false);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-2,dp(context,40));bp.setMargins(dp(context,2),0,dp(context,2),0);footer.addView(button,bp);}
  }
 }
 static final class Positioner implements ViewTreeObserver.OnGlobalLayoutListener,View.OnLayoutChangeListener,DialogInterface.OnDismissListener {
  final Activity activity;final AlertDialog dialog;final Supplier<View> anchor;final View decor,activityDecor,panel;boolean fitting;
  Positioner(Activity activity,AlertDialog dialog,Supplier<View> anchor){this.activity=activity;this.dialog=dialog;this.anchor=anchor;decor=dialog.getWindow().getDecorView();activityDecor=activity.getWindow().getDecorView();panel=CompactDialog.panel(dialog);}
  void start(){dialog.setOnDismissListener(this);decor.getViewTreeObserver().addOnGlobalLayoutListener(this);activityDecor.addOnLayoutChangeListener(this);activityDecor.getViewTreeObserver().addOnGlobalLayoutListener(this);fit();}
  void fit(){if(fitting||!dialog.isShowing())return;fitting=true;try{Window window=dialog.getWindow();Rect visible=new Rect();activityDecor.getWindowVisibleDisplayFrame(visible);Rect popupVisible=new Rect();decor.getWindowVisibleDisplayFrame(popupVisible);if(popupVisible.height()>0&&Math.abs(popupVisible.width()-visible.width())<=dp(activity,2)&&popupVisible.top<=visible.top+dp(activity,2)&&popupVisible.bottom<visible.bottom)visible.bottom=popupVisible.bottom;
    if(visible.width()<=0||visible.height()<=0)visible.set(0,0,activity.getResources().getDisplayMetrics().widthPixels,activity.getResources().getDisplayMetrics().heightPixels);
    int width=Math.max(1,Math.min(dp(activity,480),visible.width()-dp(activity,12)));View target=anchor.get();int anchorTop=visible.bottom;if(target!=null&&target.getHeight()>0){int[] location=new int[2];target.getLocationOnScreen(location);if(location[1]>visible.top)anchorTop=Math.min(visible.bottom,location[1]);}
    int offset=Math.max(0,visible.bottom-anchorTop)+dp(activity,6);int available=Math.min(dp(activity,320),Math.max(dp(activity,48),visible.height()-offset-dp(activity,6)));
    panel.measure(View.MeasureSpec.makeMeasureSpec(width,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(available,View.MeasureSpec.AT_MOST));int height=Math.max(1,Math.min(available,panel.getMeasuredHeight()));WindowManager.LayoutParams attributes=window.getAttributes();int gravity=Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL;if(attributes.width!=width||attributes.height!=height||attributes.y!=offset||attributes.gravity!=gravity){attributes.width=width;attributes.height=height;attributes.y=offset;attributes.gravity=gravity;window.setAttributes(attributes);}
   }finally{fitting=false;}}
  @Override public void onGlobalLayout(){fit();}
  @Override public void onLayoutChange(View v,int l,int t,int r,int b,int ol,int ot,int or,int ob){fit();}
  @Override public void onDismiss(DialogInterface d){activityDecor.removeOnLayoutChangeListener(this);if(activityDecor.getViewTreeObserver().isAlive())activityDecor.getViewTreeObserver().removeOnGlobalLayoutListener(this);if(decor.getViewTreeObserver().isAlive())decor.getViewTreeObserver().removeOnGlobalLayoutListener(this);}
 }
}
