package com.tv2u.imagetools;
import android.annotation.TargetApi;
import android.content.ContentResolver;
import android.graphics.*;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import java.io.*;

/** Android 8/8.1 fallback avoids linking ImageDecoder before API 28. */
final class ImageLoader {
 static Bitmap load(ContentResolver resolver,Uri uri) throws IOException {
  return Build.VERSION.SDK_INT>=28?Api28.load(resolver,uri):legacy(resolver,uri);
 }
 static Bitmap legacy(ContentResolver resolver,Uri uri) throws IOException {
  BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;
  try(InputStream in=resolver.openInputStream(uri)){if(in==null)throw new IOException("Cannot open image");BitmapFactory.decodeStream(in,null,options);}
  if(options.outWidth<=0||options.outHeight<=0)throw new IOException("Unsupported image");
  options.inJustDecodeBounds=false;options.inPreferredConfig=Bitmap.Config.ARGB_8888;options.inSampleSize=1;
  while(Math.max(options.outWidth,options.outHeight)/options.inSampleSize>3840)options.inSampleSize*=2;
  Bitmap bitmap;try(InputStream in=resolver.openInputStream(uri)){if(in==null)throw new IOException("Cannot open image");bitmap=BitmapFactory.decodeStream(in,null,options);}
  if(bitmap==null)throw new IOException("Cannot decode image");
  int orientation=ExifInterface.ORIENTATION_NORMAL;try(InputStream in=resolver.openInputStream(uri)){if(in!=null)orientation=new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);}catch(IOException|RuntimeException ignored){}
  Bitmap oriented=orient(bitmap,orientation);if(oriented!=bitmap)bitmap.recycle();
  float ratio=Math.min(1f,1920f/Math.max(oriented.getWidth(),oriented.getHeight()));if(ratio<1){Bitmap out=Bitmap.createScaledBitmap(oriented,Math.max(1,Math.round(oriented.getWidth()*ratio)),Math.max(1,Math.round(oriented.getHeight()*ratio)),true);if(out!=oriented)oriented.recycle();return out;}return oriented;
 }
 static Bitmap orient(Bitmap bitmap,int orientation){
  Matrix m=new Matrix();switch(orientation){
   case ExifInterface.ORIENTATION_FLIP_HORIZONTAL:m.setScale(-1,1);break;
   case ExifInterface.ORIENTATION_ROTATE_180:m.setRotate(180);break;
   case ExifInterface.ORIENTATION_FLIP_VERTICAL:m.setScale(1,-1);break;
   case ExifInterface.ORIENTATION_TRANSPOSE:m.setRotate(90);m.postScale(-1,1);break;
   case ExifInterface.ORIENTATION_ROTATE_90:m.setRotate(90);break;
   case ExifInterface.ORIENTATION_TRANSVERSE:m.setRotate(-90);m.postScale(-1,1);break;
   case ExifInterface.ORIENTATION_ROTATE_270:m.setRotate(-90);break;
   default:return bitmap;
  }return Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),m,true);
 }
 @TargetApi(28) private static class Api28 {
  static Bitmap load(ContentResolver resolver,Uri uri) throws IOException {return ImageDecoder.decodeBitmap(ImageDecoder.createSource(resolver,uri),(decoder,details,source)->{float ratio=Math.min(1f,1920f/Math.max(details.getSize().getWidth(),details.getSize().getHeight()));decoder.setTargetSize(Math.max(1,Math.round(details.getSize().getWidth()*ratio)),Math.max(1,Math.round(details.getSize().getHeight()*ratio)));decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);});}
 }
}
