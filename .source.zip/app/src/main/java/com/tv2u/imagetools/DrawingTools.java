package com.tv2u.imagetools;

import android.graphics.*;

/** Shared geometry/style for the live preview and exported annotations. */
final class DrawingTools {
 static boolean freehand(String tool){return tool.equals("Pen")||tool.equals("Marker");}
 static boolean shape(String tool){return tool.equals("Line")||tool.equals("Arrow")||tool.equals("Rectangle");}
 static Paint paint(String tool,float size,int color){
  Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(color);p.setStyle(Paint.Style.STROKE);
  p.setStrokeWidth(tool.equals("Marker")?size*3:size);p.setStrokeCap(tool.equals("Marker")?Paint.Cap.SQUARE:Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);
  if(tool.equals("Marker"))p.setAlpha(90);return p;
 }
 static Path shapePath(String tool,float x1,float y1,float x2,float y2,float width){
  Path path=new Path();
  if(tool.equals("Rectangle")){path.addRect(Math.min(x1,x2),Math.min(y1,y2),Math.max(x1,x2),Math.max(y1,y2),Path.Direction.CW);return path;}
  path.moveTo(x1,y1);path.lineTo(x2,y2);
  if(tool.equals("Arrow")){
   double angle=Math.atan2(y2-y1,x2-x1),length=Math.hypot(x2-x1,y2-y1);
   float head=(float)Math.min(length*.45,Math.max(18,width*4));
   path.moveTo((float)(x2-head*Math.cos(angle-.55)),(float)(y2-head*Math.sin(angle-.55)));
   path.lineTo(x2,y2);path.lineTo((float)(x2-head*Math.cos(angle+.55)),(float)(y2-head*Math.sin(angle+.55)));
  }
  return path;
 }
}
