package com.tv2u.imagetools;
import android.graphics.*;
import android.graphics.drawable.Drawable;

/** Crisp code-drawn icons; no font glyph or network asset dependency. */
final class ToolIcon extends Drawable {
 private final String tool;private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private int tint=0xff44484c;
 ToolIcon(String tool){this.tool=tool;}
 void tint(int value){tint=value;invalidateSelf();}
 @Override public void draw(Canvas c){c.save();Rect b=getBounds();c.translate(b.left,b.top);c.scale(b.width()/24f,b.height()/24f);p.setColor(tint);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.8f);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);
  switch(tool){
   case "Pen":Path pencil=new Path();pencil.moveTo(6,14);pencil.lineTo(14,4);pencil.lineTo(19,8);pencil.lineTo(11,18);pencil.close();p.setStyle(Paint.Style.FILL);c.drawPath(pencil,p);Path cap=new Path();cap.moveTo(15,3);cap.lineTo(16.5f,1.5f);cap.quadTo(17.2f,.8f,18,1.5f);cap.lineTo(21.5f,4.3f);cap.quadTo(22.2f,5,21.5f,5.8f);cap.lineTo(20,7.2f);cap.close();c.drawPath(cap,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);Path nib=new Path();nib.moveTo(6,14);nib.lineTo(3,21);nib.lineTo(11,18);c.drawPath(nib,p);Path trace=new Path();trace.moveTo(3,22);trace.cubicTo(7,20,10,23,13,21);trace.cubicTo(15,19,18,23,21,21);c.drawPath(trace,p);break;
   case "Line":c.drawLine(5,19,19,5,p);break;
   case "Arrow":c.drawLine(4,20,20,4,p);c.drawLine(11,4,20,4,p);c.drawLine(20,4,20,13,p);break;
   case "Rectangle":c.drawRect(4,6,20,18,p);break;
   case "Marker":c.drawLine(6,17,16,4,p);c.drawLine(16,4,21,8,p);c.drawLine(21,8,11,20,p);c.drawLine(6,17,11,20,p);p.setStrokeWidth(3);c.drawLine(4,22,14,22,p);break;
   case "Text":c.drawLine(5,5,19,5,p);c.drawLine(12,5,12,20,p);c.drawLine(8,20,16,20,p);break;
   case "Blur":for(int y=5;y<=19;y+=7)for(int x=5;x<=19;x+=7){p.setAlpha((x+y)%3==0?90:220);c.drawCircle(x,y,2,p);}p.setAlpha(255);break;
   case "Unblur":c.drawCircle(12,12,8,p);c.drawLine(6,18,18,6,p);break;
   case "Crop":c.drawLine(7,3,7,17,p);c.drawLine(7,17,21,17,p);c.drawLine(3,7,17,7,p);c.drawLine(17,7,17,21,p);break;
   case "Rotate":c.drawArc(4,4,20,20,205,285,false,p);c.drawLine(3,6,3,12,p);c.drawLine(3,12,9,12,p);break;
   case "Straighten":c.drawLine(3,17,21,7,p);c.drawLine(3,21,21,21,p);c.drawCircle(12,12,2,p);break;
   case "Perspective":Path quad=new Path();quad.moveTo(5,5);quad.lineTo(21,3);quad.lineTo(18,20);quad.lineTo(3,18);quad.close();c.drawPath(quad,p);for(float[] pt:new float[][]{{5,5},{21,3},{18,20},{3,18}})c.drawCircle(pt[0],pt[1],1.8f,p);break;
   case "Undo":c.drawArc(5,7,21,21,205,245,false,p);c.drawLine(4,5,4,12,p);c.drawLine(4,12,11,12,p);break;
   case "Redo":c.drawArc(3,7,19,21,90,245,false,p);c.drawLine(20,5,20,12,p);c.drawLine(20,12,13,12,p);break;
   case "Copy":c.drawRect(8,8,20,21,p);c.drawLine(4,16,4,3,p);c.drawLine(4,3,16,3,p);break;
   case "Save":c.drawRect(4,3,20,21,p);c.drawRect(8,3,16,9,p);c.drawRect(8,14,16,21,p);break;
   case "Share":c.drawCircle(6,12,2.5f,p);c.drawCircle(18,5,2.5f,p);c.drawCircle(18,19,2.5f,p);c.drawLine(8,11,16,6,p);c.drawLine(8,13,16,18,p);break;
   case "Print":c.drawRect(4,8,20,18,p);c.drawRect(7,2,17,8,p);c.drawRect(7,14,17,22,p);c.drawPoint(17,11,p);break;
   case "Close":c.drawLine(5,5,19,19,p);c.drawLine(19,5,5,19,p);break;
   case "Upload":c.drawArc(3,8,13,18,100,240,false,p);c.drawArc(9,5,21,18,210,260,false,p);c.drawLine(6,18,18,18,p);c.drawLine(12,20,12,9,p);c.drawLine(8,13,12,9,p);c.drawLine(12,9,16,13,p);break;
   case "Search":c.drawCircle(10,10,6,p);c.drawLine(14.5f,14.5f,21,21,p);break;
   case "Move image":Path hand=new Path();hand.moveTo(5,13);hand.lineTo(5,9);hand.quadTo(5,7,7,8);hand.lineTo(7,4);hand.quadTo(8,2,10,4);hand.lineTo(10,10);hand.lineTo(10,3);hand.quadTo(12,1,13,3);hand.lineTo(13,10);hand.lineTo(13,4);hand.quadTo(15,2,16,4);hand.lineTo(16,11);hand.lineTo(16,7);hand.quadTo(19,5,19,8);hand.lineTo(19,15);hand.lineTo(16,21);hand.lineTo(8,21);hand.lineTo(3,14);hand.quadTo(2,11,5,13);c.drawPath(hand,p);break;
   case "Zoom in":case "Zoom out":c.drawCircle(10,10,6,p);c.drawLine(14.5f,14.5f,21,21,p);c.drawLine(7,10,13,10,p);if(tool.equals("Zoom in"))c.drawLine(10,7,10,13,p);break;
   case "Fit image":c.drawRect(6,7,18,17,p);c.drawLine(3,8,3,3,p);c.drawLine(3,3,8,3,p);c.drawLine(16,3,21,3,p);c.drawLine(21,3,21,8,p);c.drawLine(3,16,3,21,p);c.drawLine(3,21,8,21,p);c.drawLine(16,21,21,21,p);c.drawLine(21,21,21,16,p);break;
   case "Size":c.drawLine(4,6,20,6,p);c.drawCircle(9,6,2.5f,p);c.drawLine(4,12,20,12,p);c.drawCircle(16,12,2.5f,p);c.drawLine(4,18,20,18,p);c.drawCircle(7,18,2.5f,p);break;
   case "Color":c.drawCircle(12,12,8,p);c.drawCircle(12,12,3,p);c.drawLine(12,2,12,5,p);c.drawLine(12,19,12,22,p);break;
   case "More":p.setStyle(Paint.Style.FILL);c.drawCircle(5,12,1.6f,p);c.drawCircle(12,12,1.6f,p);c.drawCircle(19,12,1.6f,p);break;
   default:break;
  }c.restore();
 }
 @Override public void setAlpha(int alpha){p.setAlpha(alpha);invalidateSelf();}
 @Override public void setColorFilter(ColorFilter filter){p.setColorFilter(filter);invalidateSelf();}
 @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
