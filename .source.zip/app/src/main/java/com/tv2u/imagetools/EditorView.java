package com.tv2u.imagetools;
import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.function.Consumer;

/** Only draws one cached bitmap and lightweight gesture previews. */
public final class EditorView extends View {
 Bitmap image; String tool="Pen",text=""; int color=0xffe65900,size=12; boolean busy,selected,drawing;
 float textSize=60,textOffsetX,textOffsetY,resizeStart,resizeDistance,resizeOriginY;int textWidth,textHeight;boolean resizingText;
 java.util.function.BiConsumer<Float,Float> pickText;
 final Matrix textTransform=new Matrix(),textInverse=new Matrix();
 float angle,textX,textY,scale=1,startX,startY,lastX,lastY; int handle=-1;
 float zoom=1,centerX,centerY,gestureX,gestureY,gestureDistance;boolean navigating,fitPending;
 final Matrix imageToView=new Matrix(),viewToImage=new Matrix();
 final float[] quad=new float[8],initialQuad=new float[8];
 final RectF display=new RectF(),selection=new RectF(),initial=new RectF(); final Path path=new Path();final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
 int reservedRight,reservedBottom; Runnable dockChanged;
 final RectF previousDock=new RectF();
 Consumer<EditDocument.Op> commit; Runnable changed;
 EditorView(Context context){super(context);setContentDescription("Image editor canvas");}
 boolean ready(){return image!=null;}
 void show(Bitmap b){boolean reset=image==null||image.getWidth()!=b.getWidth()||image.getHeight()!=b.getHeight();image=b;if(reset){zoom=1;centerX=b.getWidth()/2f;centerY=b.getHeight()/2f;}clear();signal();}
 void clear(){textTransform.reset();selected=false;drawing=false;angle=0;selection.setEmpty();path.reset();invalidate();}
 void signal(){invalidate();if(changed!=null)changed.run();}
 void choose(String t){clear();tool=t;if(t.equals("Crop")&&ready()){selection.set(image.getWidth()*.08f,image.getHeight()*.08f,image.getWidth()*.92f,image.getHeight()*.92f);selected=true;}if(t.equals("Perspective")&&ready())initPerspective();if(selectionMode()&&ready())fitImage();signal();}
 float fontSize(){return textSize;}
 Paint textPaint(){Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setColor(color);paint.setTextSize(fontSize());paint.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));return paint;}
 void startText(String s){choose("Text");text=s;textWidth=image.getWidth();textHeight=image.getHeight();updateViewport();float[] middle=sourcePoint((getWidth()-reservedRight)/2f,getHeight()/2f);RectF bounds=TextLayer.bounds(s,0,0,textSize);textX=Math.max(0,middle[0]-bounds.width()/2);textY=Math.max(textSize,middle[1]);selected=true;signal();}
 void startExisting(TextLayer layer){choose("Text");text=layer.op.text;textX=layer.op.x;textY=layer.op.y;textSize=layer.op.size;color=layer.op.color;textWidth=layer.width;textHeight=layer.height;textTransform.set(layer.transform);selected=true;signal();}
 RectF textBounds(){return TextLayer.bounds(text,textX,textY,fontSize());}
 void resizeText(float value){textSize=Math.max(10,Math.min(300,value));signal();}
 boolean textTouch(MotionEvent e,float x,float y){
  if(!selected){if(e.getActionMasked()==MotionEvent.ACTION_DOWN&&pickText!=null)pickText.accept(x,y);return true;}
  textTransform.invert(textInverse);float[] local={x,y};textInverse.mapPoints(local);x=local[0];y=local[1];RectF bounds=textBounds();float reach=24/Math.max(.01f,scale*textTransform.mapRadius(1));
  switch(e.getActionMasked()){
   case MotionEvent.ACTION_DOWN:
    resizingText=Math.hypot(x-bounds.right,y-bounds.bottom)<reach;
    RectF hit=new RectF(bounds);hit.inset(-reach,-reach);
    if(!resizingText&&!hit.contains(x,y)){if(pickText!=null)pickText.accept((float)sourcePoint(e.getX(),e.getY())[0],(float)sourcePoint(e.getX(),e.getY())[1]);return true;}
    drawing=true;textOffsetX=textX-x;textOffsetY=textY-y;resizeStart=textSize;resizeOriginY=bounds.top;resizeDistance=Math.max(1,(float)Math.hypot(bounds.right-textX,bounds.bottom-(textY+textPaint().ascent())));break;
   case MotionEvent.ACTION_MOVE:if(drawing){if(resizingText){float dist=(float)Math.hypot(x-textX,y-resizeOriginY);resizeText(resizeStart*dist/resizeDistance);}else{textX=x+textOffsetX;textY=y+textOffsetY;}invalidate();}break;
   case MotionEvent.ACTION_UP:drawing=false;performClick();signal();break;
   case MotionEvent.ACTION_CANCEL:drawing=false;signal();break;
  }return true;
 }
 void apply(){
  if(busy||!ready()||!selected)return;
  if(tool.equals("Text")){commit.accept(EditDocument.Op.text(text,textX,textY,fontSize(),color));}
  else if(tool.equals("Perspective")){if(PerspectiveWarp.valid(quad))commit.accept(EditDocument.Op.perspective(quad));}
  else if(tool.equals("Straighten")){if(Math.abs(angle)>.01f)commit.accept(EditDocument.Op.rotate(angle));else{clear();signal();}}
  else {Rect r=new Rect(Math.max(0,(int)selection.left),Math.max(0,(int)selection.top),Math.min(image.getWidth(),(int)Math.ceil(selection.right)),Math.min(image.getHeight(),(int)Math.ceil(selection.bottom)));if(r.width()>=2&&r.height()>=2)commit.accept(EditDocument.Op.region(tool,r));}
 }
 @Override protected void onDraw(Canvas c){
  c.drawColor(0xffe7e9ec);
  if(!ready()){p.reset();p.setAntiAlias(true);p.setColor(0xff697586);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(16*getResources().getDisplayMetrics().scaledDensity);c.drawText("Import a photo to begin",getWidth()/2f,getHeight()/2f,p);return;}
  updateViewport();if(scale<=0)return;
  RectF dock=toolBounds();if(!dock.equals(previousDock)){previousDock.set(dock);if(dockChanged!=null)post(dockChanged);}
  c.save();c.clipRect(0,0,getWidth()-reservedRight,getHeight()-reservedBottom);c.concat(imageToView);
  p.reset();p.setColor(Color.WHITE);c.drawRect(0,0,image.getWidth(),image.getHeight(),p);
  c.drawBitmap(image,0,0,null);
  if(!tool.equals("Crop")&&!tool.equals("Perspective")){p.reset();p.setColor(0xffaab3c0);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1/scale);c.drawRect(0,0,image.getWidth(),image.getHeight(),p);p.setStyle(Paint.Style.FILL);p.setColor(0xff475467);p.setTextSize(11/scale);c.drawText(image.getWidth()+" × "+image.getHeight(),0,display.top>=20?-7/scale:15/scale,p);}
  if(selected&&tool.equals("Perspective")){
   Path polygon=quadPath();Path shade=new Path();shade.addRect(0,0,image.getWidth(),image.getHeight(),Path.Direction.CW);shade.addPath(polygon);shade.setFillType(Path.FillType.EVEN_ODD);p.reset();p.setColor(0x66000000);c.drawPath(shade,p);p.setColor(0xffe65900);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2/scale);c.drawPath(polygon,p);p.setStyle(Paint.Style.FILL);for(int i=0;i<4;i++)drawHandle(c,quad[i*2],quad[i*2+1]);p.reset();p.setColor(0xff344054);
   if(PerspectiveWarp.valid(quad)){int[] out=PerspectiveWarp.outputSize(quad);drawBadge(c,out[0]+" × "+out[1],quad[0],quad[1]);}
  }
  if(drawing&&DrawingTools.freehand(tool))c.drawPath(path,DrawingTools.paint(tool,size,color));
  if(drawing&&DrawingTools.shape(tool))c.drawPath(DrawingTools.shapePath(tool,startX,startY,lastX,lastY,size),DrawingTools.paint(tool,size,color));
  if(selected&&tool.equals("Text")){c.save();c.concat(textTransform);Paint tp=textPaint();float y=textY;for(String line:text.split("\n",-1)){c.drawText(line,textX,y,tp);y+=fontSize()*1.25f;}RectF bounds=textBounds();p.reset();p.setAntiAlias(true);p.setColor(0xffe65900);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f/Math.max(.01f,scale*textTransform.mapRadius(1)));c.drawRect(bounds,p);p.setStyle(Paint.Style.FILL);c.drawCircle(bounds.right,bounds.bottom,7/Math.max(.01f,scale*textTransform.mapRadius(1)),p);c.restore();}
  if((selected||drawing)&&(tool.equals("Crop")||tool.equals("Blur")||tool.equals("Unblur"))){
   p.reset();
   if(tool.equals("Crop")){
    p.setColor(0x66000000);c.drawRect(0,0,image.getWidth(),selection.top,p);c.drawRect(0,selection.bottom,image.getWidth(),image.getHeight(),p);c.drawRect(0,selection.top,selection.left,selection.bottom,p);c.drawRect(selection.right,selection.top,image.getWidth(),selection.bottom,p);
   }else{p.setColor(0x33ff7900);c.drawRect(selection,p);}
   p.setColor(0xff536170);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f/scale);p.setPathEffect(new DashPathEffect(new float[]{4/scale,3/scale},0));c.drawRect(selection,p);p.setPathEffect(null);p.setStyle(Paint.Style.FILL);
   if(tool.equals("Crop"))drawBadge(c,Math.round(selection.width())+" × "+Math.round(selection.height()),selection.left,selection.top);
   for(int i=0;i<4;i++)drawHandle(c,i%2==0?selection.left:selection.right,i<2?selection.top:selection.bottom);
  }c.restore();
  if(tool.equals("Straighten")){p.reset();p.setColor(0x88ffffff);p.setStrokeWidth(1);for(int i=1;i<3;i++){c.drawLine(getWidth()*i/3f,12,getWidth()*i/3f,getHeight()-12,p);c.drawLine(12,getHeight()*i/3f,getWidth()-12,getHeight()*i/3f,p);}}
 }
 void drawBadge(Canvas canvas,String text,float x,float y){p.reset();p.setAntiAlias(true);p.setTextSize(11/scale);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));float width=p.measureText(text)+10/scale,top=Math.max(0,y-21/scale);p.setColor(0xff3d444d);canvas.drawRoundRect(x,top,x+width,top+18/scale,2/scale,2/scale,p);p.setColor(Color.WHITE);canvas.drawText(text,x+5/scale,top+13/scale,p);}
 void drawHandle(Canvas canvas,float x,float y){p.reset();p.setColor(Color.WHITE);canvas.drawRect(x-4/scale,y-4/scale,x+4/scale,y+4/scale,p);p.setColor(0xff536170);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1/scale);canvas.drawRect(x-4/scale,y-4/scale,x+4/scale,y+4/scale,p);}
 void initPerspective(){float w=image.getWidth(),h=image.getHeight();float[] start={w*.08f,h*.08f,w*.92f,h*.08f,w*.92f,h*.92f,w*.08f,h*.92f};System.arraycopy(start,0,quad,0,8);selected=true;}
 Path quadPath(){Path path=new Path();path.moveTo(quad[0],quad[1]);for(int i=1;i<4;i++)path.lineTo(quad[i*2],quad[i*2+1]);path.close();return path;}
 boolean perspectiveTouch(MotionEvent e,float x,float y){
  switch(e.getActionMasked()){
   case MotionEvent.ACTION_DOWN:if(!display.contains(e.getX(),e.getY()))return true;if(!selected)initPerspective();drawing=true;startX=x;startY=y;System.arraycopy(quad,0,initialQuad,0,8);handle=4;float closest=32/scale;for(int i=0;i<4;i++){float d=(float)Math.hypot(x-quad[i*2],y-quad[i*2+1]);if(d<closest){closest=d;handle=i;}}break;
   case MotionEvent.ACTION_MOVE:if(drawing)movePerspective(x,y);break;
   case MotionEvent.ACTION_UP:if(drawing)movePerspective(x,y);drawing=false;performClick();signal();break;
   case MotionEvent.ACTION_CANCEL:drawing=false;signal();break;
  }invalidate();return true;
 }
 void movePerspective(float x,float y){float[] next=quad.clone();if(handle<4){next[handle*2]=x;next[handle*2+1]=y;}else{float minX=initialQuad[0],maxX=minX,minY=initialQuad[1],maxY=minY;for(int i=1;i<4;i++){minX=Math.min(minX,initialQuad[i*2]);maxX=Math.max(maxX,initialQuad[i*2]);minY=Math.min(minY,initialQuad[i*2+1]);maxY=Math.max(maxY,initialQuad[i*2+1]);}float dx=Math.max(-minX,Math.min(image.getWidth()-maxX,x-startX)),dy=Math.max(-minY,Math.min(image.getHeight()-maxY,y-startY));for(int i=0;i<4;i++){next[i*2]=initialQuad[i*2]+dx;next[i*2+1]=initialQuad[i*2+1]+dy;}}if(PerspectiveWarp.valid(next))System.arraycopy(next,0,quad,0,8);}
 RectF toolBounds(){
  RectF r=new RectF(0,0,image==null?0:image.getWidth(),image==null?0:image.getHeight());
  if(selected&&tool.equals("Perspective"))quadPath().computeBounds(r,true);
  else if(selected&&tool.equals("Crop")&&!selection.isEmpty())r.set(selection);
  imageToView.mapRect(r);return r;
 }
 boolean selectionMode(){return tool.equals("Perspective")||tool.equals("Crop");}
 float coverScale(){float w=Math.max(1,getWidth()-reservedRight),h=Math.max(1,getHeight()-reservedBottom);double radians=Math.toRadians(angle);float co=(float)Math.abs(Math.cos(radians)),si=(float)Math.abs(Math.sin(radians));return Math.max((w*co+h*si)/image.getWidth(),(w*si+h*co)/image.getHeight());}
 float minimumZoom(){if(!ready()||!selectionMode())return 1;float w=Math.max(1,getWidth()-reservedRight),h=Math.max(1,getHeight()-reservedBottom);return Math.min(w/image.getWidth(),h/image.getHeight())/coverScale();}
 void fitImage(){if(busy||!ready())return;fitPending=true;centerX=image.getWidth()/2f;centerY=image.getHeight()/2f;updateViewport();signal();}
 void changeZoom(float factor){if(busy||!ready())return;fitPending=false;zoom=Math.max(minimumZoom(),Math.min(8,zoom*factor));updateViewport();signal();}
 void updateViewport(){
  if(!ready())return;float w=Math.max(1,getWidth()-reservedRight),h=Math.max(1,getHeight()-reservedBottom);
  double radians=Math.toRadians(angle);float co=(float)Math.abs(Math.cos(radians)),si=(float)Math.abs(Math.sin(radians));
  // Cover the viewport, even while straightening; never stretch source pixels.
  if(fitPending&&getWidth()>reservedRight&&getHeight()>reservedBottom){zoom=minimumZoom();fitPending=false;}
  zoom=Math.max(minimumZoom(),Math.min(8,zoom));
  scale=coverScale()*zoom;
  float halfX=Math.min(image.getWidth()/2f,(w*co+h*si)/(2*scale)),halfY=Math.min(image.getHeight()/2f,(w*si+h*co)/(2*scale));
  centerX=Math.max(halfX,Math.min(image.getWidth()-halfX,centerX));centerY=Math.max(halfY,Math.min(image.getHeight()-halfY,centerY));
  imageToView.reset();imageToView.postTranslate(-centerX,-centerY);imageToView.postScale(scale,scale);imageToView.postRotate(angle);imageToView.postTranslate(w/2,h/2);
  imageToView.invert(viewToImage);display.set(0,0,image.getWidth(),image.getHeight());imageToView.mapRect(display);
 }
 float[] sourcePoint(float x,float y){float[] point={x,y};viewToImage.mapPoints(point);return point;}
 boolean navigate(MotionEvent e){
  int action=e.getActionMasked();
  if(action==MotionEvent.ACTION_POINTER_DOWN&&e.getPointerCount()>=2){navigating=true;drawing=false;path.reset();gestureX=(e.getX(0)+e.getX(1))/2;gestureY=(e.getY(0)+e.getY(1))/2;gestureDistance=(float)Math.hypot(e.getX(1)-e.getX(0),e.getY(1)-e.getY(0));invalidate();return true;}
  if(!navigating)return false;
  if(action==MotionEvent.ACTION_MOVE&&e.getPointerCount()>=2){
   float x=(e.getX(0)+e.getX(1))/2,y=(e.getY(0)+e.getY(1))/2,distance=(float)Math.hypot(e.getX(1)-e.getX(0),e.getY(1)-e.getY(0));
   updateViewport();float[] anchor=sourcePoint(gestureX,gestureY);if(gestureDistance>1&&distance>1)zoom=Math.max(minimumZoom(),Math.min(8,zoom*distance/gestureDistance));updateViewport();float[] next=sourcePoint(x,y);centerX+=anchor[0]-next[0];centerY+=anchor[1]-next[1];updateViewport();gestureX=x;gestureY=y;gestureDistance=distance;invalidate();
  }
  if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){navigating=false;drawing=false;signal();}
  return true;
 }
 void penStyle(){p.reset();p.setAntiAlias(true);p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(size);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);}
 float clamp(float value,float max){return Math.max(0,Math.min(max,value));}
 @Override public boolean onTouchEvent(MotionEvent e){
  if(busy||!ready())return true;updateViewport();if(navigate(e))return true;
  if(tool.equals("Straighten")||tool.equals("Rotate")||scale<=0)return true;
  float[] point=sourcePoint(e.getX(),e.getY());float x=clamp(point[0],image.getWidth()),y=clamp(point[1],image.getHeight());
  if(tool.equals("Perspective"))return perspectiveTouch(e,x,y);
  if(tool.equals("Text"))return textTouch(e,x,y);
  switch(e.getActionMasked()){
   case MotionEvent.ACTION_DOWN:
    if(!display.contains(e.getX(),e.getY()))return true;
    drawing=true;startX=lastX=x;startY=lastY=y;
    if(DrawingTools.freehand(tool)){path.reset();path.moveTo(x,y);path.lineTo(x+.01f,y+.01f);}
    else if(DrawingTools.shape(tool)){selected=false;}
    else if(tool.equals("Text")){if(!selected)return true;placeText(x,y);}
    else{handle=-1;initial.set(selection);float reach=24/scale;
     if(selected&&tool.equals("Crop")){for(int i=0;i<4;i++)if(Math.hypot(x-(i%2==0?selection.left:selection.right),y-(i<2?selection.top:selection.bottom))<reach)handle=i;if(handle<0&&selection.contains(x,y))handle=4;}
     if(handle<0){selection.set(x,y,x,y);selected=false;}
    }break;
   case MotionEvent.ACTION_MOVE: if(!drawing)return true;
    lastX=x;lastY=y;if(DrawingTools.freehand(tool))path.lineTo(x,y);else if(tool.equals("Text"))placeText(x,y);else if(!DrawingTools.shape(tool))moveSelection(x,y);break;
   case MotionEvent.ACTION_UP: if(!drawing)return true;drawing=false;
    if(DrawingTools.freehand(tool)){path.lineTo(x,y);commit.accept(EditDocument.Op.stroke(tool,path,size,color));}
    else if(DrawingTools.shape(tool)){lastX=x;lastY=y;if(Math.hypot(x-startX,y-startY)>=2)commit.accept(EditDocument.Op.stroke(tool,DrawingTools.shapePath(tool,startX,startY,x,y,size),size,color));}
    else if(!tool.equals("Text")){moveSelection(x,y);selected=selection.width()>=2&&selection.height()>=2;if(selected&&(tool.equals("Blur")||tool.equals("Unblur")))apply();}
    performClick();signal();break;
   case MotionEvent.ACTION_CANCEL:drawing=false;path.reset();signal();break;
  }invalidate();return true;
 }
 void placeText(float x,float y){Paint paint=textPaint();float width=0;for(String line:text.split("\n",-1))width=Math.max(width,paint.measureText(line));textX=clamp(x,Math.max(0,image.getWidth()-width));textY=Math.max(fontSize(),Math.min(image.getHeight()-4,y));}
 void moveSelection(float x,float y){
  if(handle==4){float dx=Math.max(-initial.left,Math.min(image.getWidth()-initial.right,x-startX)),dy=Math.max(-initial.top,Math.min(image.getHeight()-initial.bottom,y-startY));selection.set(initial);selection.offset(dx,dy);}
  else if(handle>=0){float ox=handle%2==0?initial.right:initial.left,oy=handle<2?initial.bottom:initial.top;selection.set(Math.min(x,ox),Math.min(y,oy),Math.max(x,ox),Math.max(y,oy));}
  else selection.set(Math.min(x,startX),Math.min(y,startY),Math.max(x,startX),Math.max(y,startY));
 }
 @Override public boolean performClick(){super.performClick();return true;}
}
