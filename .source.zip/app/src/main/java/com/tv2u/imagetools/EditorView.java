package com.tv2u.imagetools;
import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.function.Consumer;

/** Only draws one cached bitmap and lightweight gesture previews. */
public final class EditorView extends View {
 Bitmap image; String tool="Pen",text=""; int color=0xffe65900,size=12; boolean busy,selected,drawing;
 float angle,textX,textY,scale=1,startX,startY,lastX,lastY; int handle=-1;
 final RectF display=new RectF(),selection=new RectF(),initial=new RectF(); final Path path=new Path();final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
 Consumer<EditDocument.Op> commit; Runnable changed;
 EditorView(Context context){super(context);setContentDescription("Image editor canvas");}
 boolean ready(){return image!=null;}
 void show(Bitmap b){image=b;clear();signal();}
 void clear(){selected=false;drawing=false;angle=0;selection.setEmpty();path.reset();invalidate();}
 void signal(){invalidate();if(changed!=null)changed.run();}
 void choose(String t){clear();tool=t;if(t.equals("Crop")&&ready()){selection.set(image.getWidth()*.08f,image.getHeight()*.08f,image.getWidth()*.92f,image.getHeight()*.92f);selected=true;}signal();}
 float fontSize(){return size*5f;}
 Paint textPaint(){Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setColor(color);paint.setTextSize(fontSize());paint.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));return paint;}
 void startText(String s){choose("Text");text=s;Paint paint=textPaint();float width=0;for(String line:s.split("\n",-1))width=Math.max(width,paint.measureText(line));textX=Math.max(4,(image.getWidth()-width)/2);textY=Math.max(fontSize(),image.getHeight()/2f);selected=true;signal();}
 void apply(){
  if(busy||!ready()||!selected)return;
  if(tool.equals("Text")){commit.accept(EditDocument.Op.text(text,textX,textY,fontSize(),color));}
  else if(tool.equals("Rotate")){if(Math.abs(angle)>.01f)commit.accept(EditDocument.Op.rotate(angle));else{clear();signal();}}
  else {Rect r=new Rect(Math.max(0,(int)selection.left),Math.max(0,(int)selection.top),Math.min(image.getWidth(),(int)Math.ceil(selection.right)),Math.min(image.getHeight(),(int)Math.ceil(selection.bottom)));if(r.width()>=2&&r.height()>=2)commit.accept(EditDocument.Op.region(tool,r));}
 }
 @Override protected void onDraw(Canvas c){
  c.drawColor(Color.WHITE);
  if(!ready()){p.reset();p.setAntiAlias(true);p.setColor(0xff697586);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(16*getResources().getDisplayMetrics().scaledDensity);c.drawText("Import a photo to begin",getWidth()/2f,getHeight()/2f,p);return;}
  float rad=(float)Math.toRadians(angle),bw=(float)(Math.abs(image.getWidth()*Math.cos(rad))+Math.abs(image.getHeight()*Math.sin(rad))),bh=(float)(Math.abs(image.getHeight()*Math.cos(rad))+Math.abs(image.getWidth()*Math.sin(rad)));
  scale=Math.min((getWidth()-24f)/Math.max(1,bw),(getHeight()-24f)/Math.max(1,bh));if(scale<=0)return;
  float left=(getWidth()-image.getWidth()*scale)/2,top=(getHeight()-image.getHeight()*scale)/2;display.set(left,top,left+image.getWidth()*scale,top+image.getHeight()*scale);
  c.save();c.translate(getWidth()/2f,getHeight()/2f);c.rotate(angle);c.scale(scale,scale);c.translate(-image.getWidth()/2f,-image.getHeight()/2f);
  p.reset();p.setColor(Color.WHITE);c.drawRect(0,0,image.getWidth(),image.getHeight(),p);
  c.drawBitmap(image,0,0,null);
  if(drawing&&tool.equals("Pen")){penStyle();c.drawPath(path,p);}
  if(selected&&tool.equals("Text")){Paint tp=textPaint();float y=textY;for(String line:text.split("\n",-1)){c.drawText(line,textX,y,tp);y+=fontSize()*1.25f;}}
  if((selected||drawing)&&!tool.equals("Text")&&!tool.equals("Pen")&&!tool.equals("Rotate")){
   p.reset();p.setColor(0x44ff7900);c.drawRect(selection,p);p.setColor(0xffe65900);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2/scale);c.drawRect(selection,p);p.setStyle(Paint.Style.FILL);
   for(int i=0;i<4;i++)c.drawCircle(i%2==0?selection.left:selection.right,i<2?selection.top:selection.bottom,6/scale,p);
  }c.restore();
  if(tool.equals("Rotate")){p.reset();p.setColor(0x88ffffff);p.setStrokeWidth(1);for(int i=1;i<3;i++){c.drawLine(getWidth()*i/3f,12,getWidth()*i/3f,getHeight()-12,p);c.drawLine(12,getHeight()*i/3f,getWidth()-12,getHeight()*i/3f,p);}}
 }
 void penStyle(){p.reset();p.setAntiAlias(true);p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(size);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);}
 float clamp(float value,float max){return Math.max(0,Math.min(max,value));}
 @Override public boolean onTouchEvent(MotionEvent e){
  if(busy||!ready()||tool.equals("Rotate")||scale<=0)return true;
  float x=clamp((e.getX()-display.left)/scale,image.getWidth()),y=clamp((e.getY()-display.top)/scale,image.getHeight());
  switch(e.getActionMasked()){
   case MotionEvent.ACTION_DOWN:
    if(!display.contains(e.getX(),e.getY()))return true;
    drawing=true;startX=lastX=x;startY=lastY=y;
    if(tool.equals("Pen")){path.reset();path.moveTo(x,y);path.lineTo(x+.01f,y+.01f);}
    else if(tool.equals("Text")){if(!selected)return true;placeText(x,y);}
    else{handle=-1;initial.set(selection);float reach=24/scale;
     if(selected&&tool.equals("Crop")){for(int i=0;i<4;i++)if(Math.hypot(x-(i%2==0?selection.left:selection.right),y-(i<2?selection.top:selection.bottom))<reach)handle=i;if(handle<0&&selection.contains(x,y))handle=4;}
     if(handle<0){selection.set(x,y,x,y);selected=false;}
    }break;
   case MotionEvent.ACTION_MOVE: if(!drawing)return true;
    if(tool.equals("Pen"))path.lineTo(x,y);else if(tool.equals("Text"))placeText(x,y);else moveSelection(x,y);break;
   case MotionEvent.ACTION_UP: if(!drawing)return true;drawing=false;
    if(tool.equals("Pen")){path.lineTo(x,y);commit.accept(EditDocument.Op.pen(path,size,color));}
    else if(!tool.equals("Text")){moveSelection(x,y);selected=selection.width()>=2&&selection.height()>=2;if(selected&&(tool.equals("Blur")||tool.equals("Unblur")))apply();}
    performClick();signal();break;
   case MotionEvent.ACTION_CANCEL:drawing=false;path.reset();signal();break;
  }invalidate();return true;
 }
 void placeText(float x,float y){Paint paint=textPaint();float width=0;for(String line:text.split("\n",-1))width=Math.max(width,paint.measureText(line));textX=clamp(x,Math.max(0,image.getWidth()-width));textY=Math.max(fontSize(),Math.min(image.getHeight()-4,y));}
 void moveSelection(float x,float y){
  if(handle==4){float dx=Math.max(-initial.left,Math.min(image.getWidth()-initial.right,x-startX)),dy=Math.max(-initial.top,Math.min(image.getHeight()-initial.bottom,y-startY));selection.set(initial);selection.offset(dx,dy);}
  else if(handle>=0){float ox=handle%2==0?initial.right:initial.left,oy=handle<2?initial.bottom:initial.top;selection.set(Math.min(x,ox),Math.min(y,oy),Math.max(x,ox),Math.max(y,oy));}
  else selection.set(Math.min(x,startX),Math.min(y,startY),Math.max(x,startX),Math.max(y,startY));
 }
 @Override public boolean performClick(){super.performClick();return true;}
}
