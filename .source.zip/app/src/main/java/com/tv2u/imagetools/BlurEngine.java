package com.tv2u.imagetools;
import android.graphics.Bitmap;
/** Three separable box passes, once per import, only on the render executor. */
final class BlurEngine {
 static Bitmap blur(Bitmap src){
  float ratio=Math.min(1f,512f/Math.max(src.getWidth(),src.getHeight()));int w=Math.max(1,Math.round(src.getWidth()*ratio)),h=Math.max(1,Math.round(src.getHeight()*ratio));
  Bitmap small=Bitmap.createScaledBitmap(src,w,h,true);int[] a=new int[w*h],b=new int[w*h];small.getPixels(a,0,w,0,0,w,h);
  for(int pass=0;pass<3;pass++){box(a,b,w,h,6,true);box(b,a,w,h,6,false);}
  Bitmap blurred=Bitmap.createBitmap(a,w,h,Bitmap.Config.ARGB_8888),out=Bitmap.createScaledBitmap(blurred,src.getWidth(),src.getHeight(),true);
  if(small!=src&&small!=out)small.recycle();if(blurred!=out)blurred.recycle();return out;
 }
 private static void box(int[] in,int[] out,int w,int h,int r,boolean horizontal){
  int length=horizontal?w:h,lines=horizontal?h:w,n=r*2+1;
  for(int line=0;line<lines;line++){
   int sa=0,sr=0,sg=0,sb=0;
   for(int j=-r;j<=r;j++){int p=in[index(Math.max(0,Math.min(length-1,j)),line,w,horizontal)];sa+=p>>>24;sr+=(p>>16)&255;sg+=(p>>8)&255;sb+=p&255;}
   for(int pos=0;pos<length;pos++){
    out[index(pos,line,w,horizontal)]=(sa/n<<24)|(sr/n<<16)|(sg/n<<8)|sb/n;
    int gone=in[index(Math.max(0,pos-r),line,w,horizontal)],added=in[index(Math.min(length-1,pos+r+1),line,w,horizontal)];
    sa+=(added>>>24)-(gone>>>24);sr+=((added>>16)&255)-((gone>>16)&255);sg+=((added>>8)&255)-((gone>>8)&255);sb+=(added&255)-(gone&255);
   }
  }
 }
 private static int index(int p,int line,int w,boolean h){return h?line*w+p:p*w+line;}
}
