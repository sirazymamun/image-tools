package com.tv2u.imagetools;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
 static final int IMPORT=10,SAVE=11,UPLOAD=12,SEARCH_SAVE=13;
 static final String LAYOUT_ID="TV2U-EDITOR-R12";
 final int textColor=0xff192433,muted=0xff56616e,accent=0xffe65900,surface=0xffe7e9ec,barSurface=0xffdce0e5;
 final ExecutorService worker=Executors.newSingleThreadExecutor();
 final Map<String,ImageButton> tools=new LinkedHashMap<>();
 final List<Button> buttons=new ArrayList<>();
 EditDocument document;EditorView editor;TextView info,angleValue,strokeValue;ProgressBar progress;SeekBar size,angleBar;
 FrameLayout workspace; LinearLayout floatingTools,floatingActions,pinnedControls; GridLayout toolGrid; View statusRow,sizeRow; boolean landscapeMode,layoutPrepared;
 LinearLayout anglePanel,selectionActions;Button undo,redo,apply,cancel,colorButton;boolean busy,jpeg;Bitmap exportImage,textRestoreImage;int editingText=-1;String afterRenderTool;Button moveButton;Button sizeButton,zoomOut,zoomFit,zoomIn;LinearLayout zoomControls;
 int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
 @Override public void onCreate(Bundle saved){
  super.onCreate(saved);getWindow().setStatusBarColor(surface);getWindow().setNavigationBarColor(surface);
  getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
  LinearLayout root=column();root.setBackgroundColor(surface);setContentView(root);
  root.setOnApplyWindowInsetsListener((v,insets)->{int l,t,r,b;if(Build.VERSION.SDK_INT>=30){Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());l=bars.left;t=bars.top;r=bars.right;b=bars.bottom;}else{l=insets.getSystemWindowInsetLeft();t=insets.getSystemWindowInsetTop();r=insets.getSystemWindowInsetRight();b=insets.getSystemWindowInsetBottom();}root.setPadding(l,t,r,b);return insets;});
  LinearLayout header=row();header.setPadding(dp(8),0,dp(8),0);ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.logo);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);logo.setContentDescription("tv2u logo");header.addView(logo,new LinearLayout.LayoutParams(dp(48),dp(48)));
  LinearLayout titles=column();TextView title=label("image tools",19,textColor);title.setTypeface(null,Typeface.BOLD);title.setSingleLine(true);title.setEllipsize(android.text.TextUtils.TruncateAt.END);titles.addView(title);titles.addView(label("PHOTO EDITOR  •  v"+BuildConfig.VERSION_NAME,10,muted));header.addView(titles,new LinearLayout.LayoutParams(0,dp(48),1));Button importButton=button("Import",v->importAsk());header.addView(importButton,new LinearLayout.LayoutParams(dp(70),dp(42)));Button more=actionButton("More",v->moreActions());header.addView(more,new LinearLayout.LayoutParams(dp(44),dp(42)));root.addView(header);
  workspace=new FrameLayout(this);workspace.setBackgroundColor(surface);root.addView(workspace,new LinearLayout.LayoutParams(-1,0,1));
  editor=new EditorView(this);editor.commit=this::commit;editor.commitBatch=this::commitDrawing;editor.changed=this::update;editor.pickText=this::pickText;editor.reservedRight=dp(40);editor.reservedBottom=0;editor.dockChanged=this::positionToolbars;workspace.addView(editor,new FrameLayout.LayoutParams(-1,-1));workspace.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->positionToolbars());
  ScrollView railScroll=new ScrollView(this);railScroll.setFillViewport(false);railScroll.setVerticalScrollBarEnabled(false);LinearLayout rail=column();rail.setPadding(0,0,0,0);rail.setBackgroundColor(Color.TRANSPARENT);
  toolGrid=new GridLayout(this);toolGrid.setColumnCount(1);rail.addView(toolGrid);
  for(String name:new String[]{"Pen","Line","Arrow","Rectangle","Marker","Text","Rotate","Straighten","Perspective"}){
   ImageButton tool=new ImageButton(this);ToolIcon icon=new ToolIcon(name);tool.setImageDrawable(icon);tool.setPadding(dp(3),dp(3),dp(3),dp(3));tool.setScaleType(ImageView.ScaleType.FIT_CENTER);tool.setBackground(ToolbarSkin.button(false,getResources().getDisplayMetrics().density));String description=name.equals("Marker")?"Highlighter":name.equals("Perspective")?"Perspective Crop":name;tool.setContentDescription(description);tool.setTooltipText(description);tool.setOnClickListener(v->{if(!busy){if(editor.tool.equals(name)&&(DrawingTools.freehand(name)||DrawingTools.shape(name)))choose("Move");else choose(name);}});if(DrawingTools.freehand(name)||DrawingTools.shape(name)||name.equals("Text"))tool.setOnLongClickListener(v->{if(!busy)showWidthDialog();return true;});tools.put(name,tool);GridLayout.LayoutParams cell=new GridLayout.LayoutParams(GridLayout.spec(tools.size()-1),GridLayout.spec(0));cell.width=dp(40);cell.height=dp(44);toolGrid.addView(tool,cell);
  }
  colorButton=actionButton("Color",v->colors());colorButton.setTooltipText("Drawing color");
  railScroll.addView(rail);floatingTools=column();floatingTools.setPadding(0,0,0,0);floatingTools.setBackground(ToolbarSkin.bar(true,getResources().getDisplayMetrics().density));floatingTools.setElevation(dp(2));floatingTools.addView(railScroll,new LinearLayout.LayoutParams(-1,0,1));pinnedControls=column();moveButton=actionButton("Move image",v->choose("Move"));rail.addView(moveButton,0,new LinearLayout.LayoutParams(dp(40),dp(44)));sizeButton=actionButton("Size",v->showWidthDialog());pinnedControls.addView(sizeButton,new LinearLayout.LayoutParams(dp(40),dp(44)));pinnedControls.addView(colorButton,new LinearLayout.LayoutParams(dp(40),dp(44)));floatingTools.addView(pinnedControls,new LinearLayout.LayoutParams(-1,-2));workspace.addView(floatingTools,new FrameLayout.LayoutParams(dp(40),-1));
  LinearLayout status=row();statusRow=status;progress=new ProgressBar(this);FrameLayout.LayoutParams waiting=new FrameLayout.LayoutParams(dp(28),dp(28),Gravity.CENTER);workspace.addView(progress,waiting);info=label("Import a photo to begin",11,muted);info.setPadding(dp(6),0,0,0);status.addView(info,new LinearLayout.LayoutParams(0,dp(24),1));status.setVisibility(View.GONE);

  LinearLayout options=row();sizeRow=options;options.setPadding(dp(6),0,dp(6),0);options.addView(label("Width / text size",11,muted));size=new SeekBar(this);size.setMax(59);size.setProgress(11);size.setProgressTintList(android.content.res.ColorStateList.valueOf(accent));size.setThumbTintList(android.content.res.ColorStateList.valueOf(accent));options.addView(size,new LinearLayout.LayoutParams(0,dp(32),1));TextView sizeLabel=label("12",12,textColor);strokeValue=sizeLabel;options.addView(sizeLabel);size.setOnSeekBarChangeListener(listener(value->{editor.size=value+1;sizeLabel.setText(String.format(Locale.getDefault(),"%d",value+1));editor.invalidate();}));options.setVisibility(View.GONE);
  anglePanel=row();anglePanel.addView(label("Straighten",12,muted));angleBar=new SeekBar(this);angleBar.setMax(300);angleBar.setProgress(150);angleBar.setProgressTintList(android.content.res.ColorStateList.valueOf(accent));angleBar.setThumbTintList(android.content.res.ColorStateList.valueOf(accent));anglePanel.addView(angleBar,new LinearLayout.LayoutParams(0,dp(38),1));angleValue=label("0.0°",12,textColor);anglePanel.addView(angleValue);angleBar.setOnSeekBarChangeListener(listener(p->{editor.angle=(p-150)/10f;editor.selected=Math.abs(editor.angle)>.01;angleValue.setText(String.format(Locale.getDefault(),"%.1f°",editor.angle));editor.signal();}));anglePanel.setVisibility(View.GONE);
  selectionActions=row();cancel=button("Cancel selection",v->cancelPreview());apply=button("Apply",v->editor.apply());selectionActions.addView(cancel,cell(40));selectionActions.addView(apply,cell(40));root.addView(selectionActions);
  LinearLayout bottom=row();floatingActions=bottom;bottom.setPadding(0,0,0,0);bottom.setBackground(ToolbarSkin.bar(false,getResources().getDisplayMetrics().density));bottom.setElevation(dp(2));undo=actionButton("Undo",v->{if(!editor.undoPreview()&&document!=null)render(document.undo());});redo=actionButton("Redo",v->render(document.redo()));pinnedControls.addView(undo,new LinearLayout.LayoutParams(dp(40),dp(44)));
  for(Button button:new Button[]{actionButton("Upload",v->uploadImage()),actionButton("Share",v->format(true)),actionButton("Search",v->searchImage()),actionButton("Print",v->printImage()),actionButton("Copy",v->copyImage()),actionButton("Save",v->format(false)),actionButton("Close",v->leave())}){
   LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(40),1);bottom.addView(button,cp);
  }root.addView(bottom,new LinearLayout.LayoutParams(-1,dp(40)));
  zoomControls=row();zoomControls.setBackground(ToolbarSkin.bar(false,getResources().getDisplayMetrics().density));zoomOut=actionButton("Zoom out",v->editor.changeZoom(.8f));zoomFit=actionButton("Fit image",v->editor.fitImage());zoomIn=actionButton("Zoom in",v->editor.changeZoom(1.25f));for(Button zoomButton:new Button[]{zoomOut,zoomFit,zoomIn})zoomControls.addView(zoomButton,new LinearLayout.LayoutParams(dp(40),dp(40)));workspace.addView(zoomControls,new FrameLayout.LayoutParams(dp(120),dp(40),Gravity.LEFT|Gravity.BOTTOM));
  handleImageIntent(getIntent());
  update();if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0,this::leave);
 }
 interface IntAction{void accept(int value);}
 SeekBar.OnSeekBarChangeListener listener(IntAction action){return new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean user){if(user&&!busy)action.accept(p);}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}};}
 LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
 LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
 LinearLayout.LayoutParams cell(int height){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(height),1);p.setMargins(dp(3),dp(3),dp(3),dp(3));return p;}
 TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
 GradientDrawable shape(int fill,int border){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(3));d.setStroke(dp(1),border);return d;}
 Button button(String s,View.OnClickListener action){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setTextColor(textColor);b.setAllCaps(false);b.setMinWidth(0);b.setMinimumWidth(0);b.setPadding(dp(6),0,dp(6),0);b.setBackground(shape(barSurface,0xffd0d5dd));b.setOnClickListener(v->{if(!busy)action.onClick(v);});buttons.add(b);return b;}
 final class IconActionButton extends Button {
  final ToolIcon icon;final String name;
  IconActionButton(String name,View.OnClickListener click){super(MainActivity.this);this.name=name;icon=new ToolIcon(name);setText("");setContentDescription(name);setTooltipText(name);setMinWidth(0);setMinimumWidth(0);setMinHeight(0);setMinimumHeight(0);setPadding(0,0,0,0);setBackground(ToolbarSkin.button(false,getResources().getDisplayMetrics().density));setOnClickListener(v->{if(!busy)click.onClick(v);});}
  @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);int side=Math.min(dp(34),Math.min(getWidth()-dp(4),getHeight()-dp(4)));if(side<=0)return;int x=(getWidth()-side)/2,y=(getHeight()-side)/2;if(name.equals("Color")){Paint swatch=new Paint(3);swatch.setColor(editor==null?accent:editor.color);int inset=dp(7);canvas.drawRect(inset,inset,getWidth()-inset,getHeight()-inset,swatch);swatch.setStyle(Paint.Style.STROKE);swatch.setStrokeWidth(dp(1));swatch.setColor(0xff8a8f94);canvas.drawRect(inset,inset,getWidth()-inset,getHeight()-inset,swatch);swatch.setStyle(Paint.Style.FILL);swatch.setColor(0xcc303438);Path triangle=new Path();triangle.moveTo(getWidth()-dp(13),getHeight()-dp(8));triangle.lineTo(getWidth()-dp(8),getHeight()-dp(13));triangle.lineTo(getWidth()-dp(8),getHeight()-dp(8));triangle.close();canvas.drawPath(triangle,swatch);}else{icon.setBounds(x,y,x+side,y+side);icon.draw(canvas);}if(name.equals("Close")||name.equals("Undo")){Paint separator=new Paint(3);separator.setColor(0xffadb4bb);if(name.equals("Close"))canvas.drawLine(0,dp(6),0,getHeight()-dp(6),separator);else canvas.drawLine(dp(5),0,getWidth()-dp(5),0,separator);}}
 }
 Button actionButton(String name,View.OnClickListener click){Button button=new IconActionButton(name,click);buttons.add(button);return button;}

 void update(){if(editor==null||undo==null)return;for(Button b:buttons)b.setEnabled(!busy);editor.busy=busy;size.setEnabled(!busy);angleBar.setEnabled(!busy);progress.setVisibility(busy?View.VISIBLE:View.GONE);
  undo.setEnabled(!busy&&(!editor.pendingStrokes.isEmpty()||(document!=null&&document.cursor>0)));redo.setEnabled(!busy&&document!=null&&document.cursor<document.ops.size());apply.setEnabled(!busy&&editor.selected);cancel.setEnabled(!busy&&editor.selected);
  for(Map.Entry<String,ImageButton> e:tools.entrySet()){boolean active=editor.tool.equals(e.getKey());ImageButton b=e.getValue();b.setEnabled(!busy&&editor.ready());b.setAlpha(b.isEnabled()?1f:.4f);b.setBackground(ToolbarSkin.button(active,getResources().getDisplayMetrics().density));((ToolIcon)b.getDrawable()).tint(active?accent:textColor);}
  if(moveButton!=null){boolean moving=editor.tool.equals("Move");moveButton.setBackground(ToolbarSkin.button(moving,getResources().getDisplayMetrics().density));((IconActionButton)moveButton).icon.tint(moving?accent:textColor);}
  selectionActions.setVisibility(editor.selected?View.VISIBLE:View.GONE);
  if(zoomControls!=null)zoomControls.setVisibility(editor.ready()&&editor.selectionMode()?View.VISIBLE:View.GONE);
  colorButton.setBackground(ToolbarSkin.button(false,getResources().getDisplayMetrics().density));((IconActionButton)colorButton).icon.tint(Color.luminance(editor.color)>.45?Color.BLACK:Color.WHITE);colorButton.invalidate();
  angleValue.setText(String.format(Locale.getDefault(),"%.1f°",editor.angle));
  String hint=editor.tool.equals("Text")?"Drag text, then Apply":editor.tool.equals("Crop")?"Drag corners / move box → Apply":editor.tool.equals("Blur")||editor.tool.equals("Unblur")?"Drag area; applies on release":editor.tool.equals("Straighten")?"Straighten slider → Apply":editor.tool.equals("Perspective")?"Drag four corners → Apply":"Draw with your finger";
  info.setText(busy?"Processing… please wait":editor.ready()?(editor.tool.equals("Marker")?"Highlighter":editor.tool.equals("Perspective")?"Perspective Crop":editor.tool)+" · "+hint:"Import a photo to begin");
  for(Button b:new Button[]{undo,redo,apply,cancel})b.setAlpha(b.isEnabled()?1f:.35f);
  workspace.post(this::positionToolbars);
 }
 void positionToolbars(){
  if(workspace==null||floatingActions==null||floatingTools==null)return;
  int width=workspace.getWidth(),height=workspace.getHeight();if(width<=0||height<=0)return;
  boolean horizontal=getWindow().getDecorView().getWidth()>getWindow().getDecorView().getHeight();
  if(!layoutPrepared||horizontal!=landscapeMode){layoutPrepared=true;landscapeMode=horizontal;statusRow.setVisibility(View.GONE);sizeRow.setVisibility(View.GONE);editor.invalidate();}
  // The drawing rail is always flush with the right safe edge. Actions live in
  // the root's final row, so image/selection bounds can never move them upward.
  int toolsWidth=dp(40);
  place(floatingTools,toolsWidth,height,width-toolsWidth,0);
 }
 void place(View view,int w,int h,int x,int y){FrameLayout.LayoutParams old=(FrameLayout.LayoutParams)view.getLayoutParams();if(old.width==w&&old.height==h&&old.leftMargin==x&&old.topMargin==y)return;FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(w,h);p.leftMargin=x;p.topMargin=y;view.setLayoutParams(p);}
 boolean exportReady(){if(!editor.ready()){toast("Import a photo first");return false;}if(editor.selected){toast("Apply or cancel the preview first");return false;}return true;}
 void createPngDocument(int request){exportImage=editor.image;jpeg=false;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("image/png");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE,"tv2u-image-"+System.currentTimeMillis()+".png");startActivityForResult(i,request);}
 void uploadImage(){if(!exportReady())return;toast("Choose a cloud provider such as Drive in the storage picker");createPngDocument(UPLOAD);}
 void saveForSearch(){toast("Save PNG, then select that saved image in Google Lens");createPngDocument(SEARCH_SAVE);}
 void searchImage(){if(!exportReady())return;if(!ImageSearch.hasTarget(this)){saveForSearch();return;}exportImage=editor.image;export(null,true,false,false,true);}
 void printImage(){if(!editor.ready()){toast("Import a photo first");return;}if(editor.selected){toast("Apply or cancel the preview first");return;}ImagePrinter.print(this,editor.image);}
 void moreActions(){new AlertDialog.Builder(this).setTitle("TV2U tools").setItems(new String[]{"Select area","All drawing tools","Width / text size","About this layout"},(dialog,which)->{
  if(which==0)choose("Crop");
  else if(which==1){String[] names={"Pen","Line","Arrow","Rectangle","Highlighter","Text","Rotate","Straighten","Perspective Crop"};String[] ids={"Pen","Line","Arrow","Rectangle","Marker","Text","Rotate","Straighten","Perspective"};new AlertDialog.Builder(this).setTitle("Choose a tool").setItems(names,(d,index)->choose(ids[index])).show();}
  else if(which==2)showWidthDialog();
  else new AlertDialog.Builder(this).setTitle("tv2u-image tools").setMessage(LAYOUT_ID+" · v"+BuildConfig.VERSION_NAME+"\nTV2U items + Rotate, Straighten, Perspective Crop.").setPositiveButton("OK",null).show();
 }).show();}
 void showStraightenDialog(){
  if(anglePanel.getParent()!=null)((android.view.ViewGroup)anglePanel.getParent()).removeView(anglePanel);anglePanel.setVisibility(View.VISIBLE);anglePanel.setPadding(dp(16),dp(12),dp(16),dp(12));
  new AlertDialog.Builder(this).setTitle("Straighten").setView(anglePanel).setNegativeButton("Cancel",(d,w)->{editor.clear();update();}).setPositiveButton("Apply",(d,w)->editor.apply()).setOnCancelListener(d->{editor.clear();update();}).show();
 }
 void changeSize(boolean text,int value){if(text)editor.resizeText(value);else{editor.size=Math.max(1,Math.min(60,value));size.setProgress(editor.size-1);strokeValue.setText(String.valueOf(editor.size));editor.invalidate();}}
 void showWidthDialog(){
  final boolean text=editor.tool.equals("Text");final int minimum=text?10:1,maximum=text?300:60;
  LinearLayout content=column();content.setPadding(dp(18),dp(8),dp(18),dp(8));TextView value=label("",16,textColor);content.addView(value);
  View sample=new View(this){final Paint paint=new Paint(3);@Override protected void onDraw(Canvas c){paint.setColor(editor.color);if(text){paint.setTextSize(Math.min(dp(38),editor.fontSize()));c.drawText("Aa",dp(8),dp(42),paint);}else{paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeWidth(Math.max(1,Math.min(dp(40),editor.size)));c.drawLine(dp(20),getHeight()/2f,getWidth()-dp(20),getHeight()/2f,paint);}}};content.addView(sample,new LinearLayout.LayoutParams(-1,dp(58)));
  SeekBar width=new SeekBar(this);width.setContentDescription(text?"Text size":"Stroke width");width.setMax(maximum-minimum);width.setProgress(Math.round(text?editor.fontSize():editor.size)-minimum);value.setText((text?Math.round(editor.fontSize()):editor.size)+" px");width.setProgressTintList(android.content.res.ColorStateList.valueOf(accent));width.setThumbTintList(android.content.res.ColorStateList.valueOf(accent));content.addView(width);
  width.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar bar,int position,boolean user){if(!busy){changeSize(text,position+minimum);value.setText((position+minimum)+" px");sample.invalidate();}}public void onStartTrackingTouch(SeekBar bar){}public void onStopTrackingTouch(SeekBar bar){}});
  LinearLayout steps=row();Button smaller=new Button(this);smaller.setText("−");smaller.setContentDescription("Decrease size");smaller.setOnClickListener(v->width.setProgress(Math.max(0,width.getProgress()-1)));Button larger=new Button(this);larger.setText("+");larger.setContentDescription("Increase size");larger.setOnClickListener(v->width.setProgress(Math.min(width.getMax(),width.getProgress()+1)));steps.addView(smaller,new LinearLayout.LayoutParams(0,dp(44),1));steps.addView(larger,new LinearLayout.LayoutParams(0,dp(44),1));content.addView(steps);
  new AlertDialog.Builder(this).setTitle(text?"Text size (10–300 px)":"Stroke width (1–60 px)").setView(content).setPositiveButton("Done",null).show();
 }
 void cancelPreview(){boolean drawingTool=DrawingTools.freehand(editor.tool)||DrawingTools.shape(editor.tool);if(textRestoreImage!=null){Bitmap original=textRestoreImage;textRestoreImage=null;editingText=-1;editor.show(original);}else editor.clear();if(drawingTool)editor.choose("Move");update();}
 void pickText(float x,float y){if(document==null||busy)return;List<TextLayer> layers=document.textLayers();for(int i=layers.size()-1;i>=0;i--){TextLayer layer=layers.get(i);if(layer.contains(x,y,12/Math.max(.01f,editor.scale))){selectText(layer);return;}}toast("Tap text added in this editing session, or choose Add text.");}
 void selectText(TextLayer layer){if(busy||document==null)return;if(textRestoreImage==null)textRestoreImage=editor.image;setBusy(true);EditDocument current=document;worker.execute(()->{try{Bitmap clean=current.renderWithout(layer.index);runOnUiThread(()->{if(isDestroyed())return;editor.show(clean);editingText=layer.index;editor.startExisting(layer);setBusy(false);});}catch(Exception|OutOfMemoryError e){runOnUiThread(()->{if(!isDestroyed()){setBusy(false);cancelPreview();toast("Could not select this text. Try a smaller image.");}});}});}
 void textInput(boolean existing){EditText input=new EditText(this);input.setText(existing?editor.text:"");input.setTextColor(textColor);input.setHint("Type text here");input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);input.setMinLines(2);input.setPadding(dp(18),dp(10),dp(18),dp(10));new AlertDialog.Builder(this).setTitle(existing?"Edit text":"Add text").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Preview",(d,w)->{String text=input.getText().toString().trim();if(!text.isEmpty()){if(existing){editor.text=text;editor.signal();}else{cancelPreview();editor.startText(text);}}}).show();}
 void textActions(){
  boolean selected=editor.tool.equals("Text")&&editor.selected;
  new AlertDialog.Builder(this).setTitle("Text").setItems(new String[]{"Add text","Select / move existing text","Edit selected text","Text size"},(d,which)->{
   if(which==0)textInput(false);
   else if(which==1){cancelPreview();editor.choose("Text");List<TextLayer> layers=document.textLayers();if(layers.isEmpty()){toast("No editable text yet. Choose Add text.");return;}String[] names=new String[layers.size()+1];names[0]="Tap text on image";for(int i=0;i<layers.size();i++)names[i+1]=layers.get(i).op.text;new AlertDialog.Builder(this).setTitle("Select text").setItems(names,(dialog,index)->{if(index>0)selectText(layers.get(index-1));}).show();}
   else if(which==2){if(selected)textInput(true);else toast("Select text first.");}
   else{if(!selected){cancelPreview();editor.choose("Text");}showWidthDialog();}
  }).show();
 }
 void setBusy(boolean value){busy=value;editor.busy=value;update();}
 void commitDrawing(List<EditDocument.Op> strokes){if(document==null||busy||strokes.isEmpty())return;if(document.cursor+strokes.size()>500){toast("500 edits reached. Save and re-import to continue.");afterRenderTool=null;return;}if(afterRenderTool==null)afterRenderTool="Move";EditDocument next=document;for(EditDocument.Op op:strokes)next=next.add(op);render(next);}
 void commit(EditDocument.Op op){if(document==null||busy)return;if(document.cursor>=500){toast("500 edits reached. Save and re-import to continue.");return;}if(op.type.equals("Text")&&editingText>=0)op=EditDocument.Op.updateText(editingText,op);editingText=-1;render(document.add(op));}
 void render(EditDocument next){if(next==null||busy)return;setBusy(true);worker.execute(()->{try{Bitmap image=next.render();runOnUiThread(()->{if(isDestroyed())return;document=next;editingText=-1;textRestoreImage=null;editor.show(image);setBusy(false);if(afterRenderTool!=null){String target=afterRenderTool;afterRenderTool=null;choose(target);}});}catch(Exception|OutOfMemoryError ex){runOnUiThread(()->{if(!isDestroyed()){afterRenderTool=null;setBusy(false);cancelPreview();toast("Could not apply this edit. Try a smaller image.");}});}});}
 void choose(String t){if(!editor.ready()){toast("Import a photo first");return;}
  if(!editor.pendingStrokes.isEmpty()&&!t.equals(editor.tool)){new AlertDialog.Builder(this).setTitle("Keep this drawing?").setMessage("Apply it before switching tools, or discard the preview.").setPositiveButton("Apply",(d,w)->{afterRenderTool=t;editor.apply();}).setNegativeButton("Discard",(d,w)->{cancelPreview();choose(t);}).setNeutralButton("Keep editing",null).show();return;}
  if(editingText>=0&&!t.equals("Text"))cancelPreview();
  if(t.equals("Text")){textActions();}
  else if(t.equals("Rotate")){editor.choose(t);new AlertDialog.Builder(this).setTitle("Rotate").setItems(new String[]{"Rotate left 90°","Rotate right 90°"},(d,which)->commit(EditDocument.Op.rotate(which==0?-90:90))).show();}
  else if(t.equals("Straighten")){editor.choose(t);angleBar.setProgress(150);update();showStraightenDialog();}
  else editor.choose(t);
 }
 void colors(){LinearLayout wrap=column();wrap.setPadding(dp(16),dp(8),dp(16),dp(8));TextView preview=label("Color",18,textColor);wrap.addView(preview);LinearLayout swatches=row();wrap.addView(swatches);int[] chosen={editor.color};ArrayList<SeekBar> sliders=new ArrayList<>();
  for(int color:new int[]{0xffe65900,0xffffdc3d,0xffe52745,0xff00a66a,0xff187ae0,Color.BLACK,Color.WHITE}){Button b=new Button(this);b.setText("●");b.setTextColor(color);b.setTextSize(22);b.setMinWidth(0);b.setMinimumWidth(0);b.setPadding(0,0,0,0);b.setBackground(shape(barSurface,0xffd0d5dd));b.setOnClickListener(v->{for(int i=0;i<3;i++)sliders.get(i).setProgress((color>>(16-i*8))&255);});swatches.addView(b,cell(40));}
  for(int i=0;i<3;i++){wrap.addView(label(new String[]{"Red","Green","Blue"}[i],12,muted));SeekBar bar=new SeekBar(this);bar.setMax(255);bar.setProgress((editor.color>>(16-i*8))&255);sliders.add(bar);wrap.addView(bar);}
  for(SeekBar bar:sliders)bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){chosen[0]=Color.rgb(sliders.get(0).getProgress(),sliders.get(1).getProgress(),sliders.get(2).getProgress());preview.setText(String.format(Locale.ROOT,"#%06X",chosen[0]&0xffffff));preview.setBackgroundColor(chosen[0]);preview.setTextColor(Color.luminance(chosen[0])>.45?Color.BLACK:Color.WHITE);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
  new AlertDialog.Builder(this).setTitle("Drawing / text color").setView(wrap).setNegativeButton("Cancel",null).setPositiveButton("Use color",(d,w)->{editor.color=chosen[0];editor.invalidate();update();}).show();
 }
 void importAsk(){if(editor.ready())new AlertDialog.Builder(this).setTitle("Import another photo?").setMessage("Save your current image first. This starts a new session.").setNegativeButton("Cancel",null).setPositiveButton("Import",(d,w)->pick()).show();else pick();}
 void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,IMPORT);}
 void format(boolean share){if(!editor.ready()){toast("Import a photo first");return;}if(editor.selected){toast("Apply or cancel the preview first");return;}
  new AlertDialog.Builder(this).setTitle(share?"Share image":"Save image").setItems(new String[]{"PNG","JPEG • white background, 95%"},(d,w)->{jpeg=w==1;exportImage=editor.image;if(share)export(null,true,jpeg);else{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType(jpeg?"image/jpeg":"image/png");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE,"tv2u-image-"+System.currentTimeMillis()+(jpeg?".jpg":".png"));startActivityForResult(i,SAVE);}}).show();
 }
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
  if(request==UPLOAD||request==SEARCH_SAVE){if(result==RESULT_OK&&data!=null)export(data.getData(),false,false,false,request==SEARCH_SAVE);else exportImage=null;return;}
  if(request==SAVE){if(result==RESULT_OK&&data!=null)export(data.getData(),false,jpeg);else exportImage=null;return;}
  if(request==IMPORT&&result==RESULT_OK&&data!=null)loadImage(data.getData());
 }
 static Uri incomingImage(Intent intent){if(intent==null||!Intent.ACTION_VIEW.equals(intent.getAction()))return null;Uri uri=intent.getData();if(uri==null||!("content".equals(uri.getScheme())||"file".equals(uri.getScheme())))return null;String type=intent.getType();return type==null||type.toLowerCase(Locale.ROOT).startsWith("image/")?uri:null;}
 void handleImageIntent(Intent intent){Uri uri=incomingImage(intent);if(uri==null)return;if(busy){toast("Please wait for processing, then open the image again.");return;}if(editor.ready())new AlertDialog.Builder(this).setTitle("Open another image?").setMessage("Save your current image first. Opening this image starts a new session.").setNegativeButton("Cancel",null).setPositiveButton("Open",(d,w)->loadImage(uri)).show();else loadImage(uri);}
 @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);handleImageIntent(intent);}
 void loadImage(Uri uri){if(uri==null||busy)return;setBusy(true);worker.execute(()->{try{
   Bitmap bitmap=ImageLoader.load(getContentResolver(),uri);EditDocument doc=new EditDocument(bitmap);Bitmap image=doc.render();runOnUiThread(()->{if(!isDestroyed()){document=doc;editingText=-1;textRestoreImage=null;afterRenderTool=null;editor.show(image);editor.choose("Move");setBusy(false);}});
  }catch(Exception|OutOfMemoryError error){runOnUiThread(()->{if(!isDestroyed()){setBusy(false);toast("Cannot open image. Try another PNG/JPEG or use Import.");}});}});
 }
 void copyImage(){if(!editor.ready()){toast("Import a photo first");return;}if(editor.selected){toast("Apply or cancel the preview first");return;}exportImage=editor.image;export(null,true,false,true);}
 void export(Uri uri,boolean share,boolean jpg){export(uri,share,jpg,false);}
 void export(Uri uri,boolean share,boolean jpg,boolean copy){export(uri,share,jpg,copy,false);}
 void export(Uri uri,boolean share,boolean jpg,boolean copy,boolean search){final Bitmap image=exportImage;exportImage=null;if(image==null){toast("Tap Save again");return;}setBusy(true);worker.execute(()->{Bitmap flattened=null;try{
  Bitmap output=image;if(jpg){flattened=EditDocument.blank(image);Canvas c=new Canvas(flattened);c.drawColor(Color.WHITE);c.drawBitmap(image,0,0,null);output=flattened;}
  File file=null;OutputStream stream;if(share){File dir=new File(getCacheDir(),"share");if(!dir.isDirectory()&&!dir.mkdirs())throw new IOException();File[] old=dir.listFiles();if(old!=null)for(File f:old)if(System.currentTimeMillis()-f.lastModified()>86400000L)f.delete();file=new File(dir,"image-"+System.currentTimeMillis()+(jpg?".jpg":".png"));stream=new FileOutputStream(file);}else stream=getContentResolver().openOutputStream(uri,"wt");
  if(stream==null)throw new IOException();try(OutputStream out=stream){if(!output.compress(jpg?Bitmap.CompressFormat.JPEG:Bitmap.CompressFormat.PNG,95,out))throw new IOException();}File shared=file;
  runOnUiThread(()->{if(isDestroyed())return;setBusy(false);if(share){Uri u=Uri.parse("content://"+getPackageName()+".share/"+shared.getName());if(search){if(!ImageSearch.launch(this,u))saveForSearch();return;}if(copy){ClipboardManager clipboard=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);clipboard.setPrimaryClip(ClipData.newUri(getContentResolver(),"tv2u image",u));toast("Image copied. Paste into an app that accepts images.");return;}Intent i=new Intent(Intent.ACTION_SEND);i.setType(jpg?"image/jpeg":"image/png");i.putExtra(Intent.EXTRA_STREAM,u);i.setClipData(ClipData.newRawUri("Edited image",u));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivity(Intent.createChooser(i,"Share image"));}catch(ActivityNotFoundException ex){toast("No share app available");}}else if(search){toast("Now choose the image you saved in Google Lens");ImageSearch.openWeb(this);}else toast("Image saved to selected location");});
 }catch(Exception|OutOfMemoryError e){runOnUiThread(()->{if(!isDestroyed()){setBusy(false);toast("Could not save/share. Check storage and try again.");}});}finally{if(flattened!=null)flattened.recycle();}});}
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
 void leave(){if(busy){toast("Please wait for processing");return;}if(editor.selected){cancelPreview();}else if(document!=null)new AlertDialog.Builder(this).setTitle("Leave editor?").setMessage("Save your image first. Unsaved edits will be lost.").setNegativeButton("Stay",null).setPositiveButton("Exit",(d,w)->finish()).show();else finish();}
 @Override public void onBackPressed(){leave();}
 @Override protected void onDestroy(){super.onDestroy();worker.shutdown();}
}
