package com.tv2u.imagetools;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
 static final int IMPORT=10,SAVE=11;
 final int textColor=0xff192433,muted=0xff667085,accent=0xffe65900;
 final ExecutorService worker=Executors.newSingleThreadExecutor();
 final Map<String,Button> tools=new LinkedHashMap<>();
 final List<Button> buttons=new ArrayList<>();
 EditDocument document;EditorView editor;TextView info,angleValue;ProgressBar progress;SeekBar size,angleBar;
 LinearLayout anglePanel;Button undo,redo,apply,cancel,colorButton;boolean busy,jpeg;Bitmap exportImage;
 int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
 @Override public void onCreate(Bundle saved){
  super.onCreate(saved);getWindow().setStatusBarColor(Color.WHITE);getWindow().setNavigationBarColor(Color.WHITE);
  getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
  LinearLayout root=column();root.setBackgroundColor(Color.WHITE);setContentView(root);
  root.setOnApplyWindowInsetsListener((v,insets)->{int l,t,r,b;if(Build.VERSION.SDK_INT>=30){Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());l=bars.left;t=bars.top;r=bars.right;b=bars.bottom;}else{l=insets.getSystemWindowInsetLeft();t=insets.getSystemWindowInsetTop();r=insets.getSystemWindowInsetRight();b=insets.getSystemWindowInsetBottom();}root.setPadding(dp(10)+l,t,dp(10)+r,b);return insets;});
  LinearLayout header=row();ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.logo);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);logo.setContentDescription("tv2u logo");header.addView(logo,new LinearLayout.LayoutParams(dp(48),dp(48)));
  LinearLayout titles=column();TextView title=label("tv2u-image tools",19,textColor);title.setTypeface(null,Typeface.BOLD);titles.addView(title);titles.addView(label("PHOTO EDITOR  •  v"+BuildConfig.VERSION_NAME,10,muted));header.addView(titles,new LinearLayout.LayoutParams(0,dp(54),1));root.addView(header);
  LinearLayout actions=row();actions.addView(button("Import",v->importAsk()),cell(42));actions.addView(button("Save",v->format(false)),cell(42));actions.addView(button("Share",v->format(true)),cell(42));root.addView(actions);
  editor=new EditorView(this);editor.commit=this::commit;editor.changed=this::update;root.addView(editor,new LinearLayout.LayoutParams(-1,0,1));
  LinearLayout status=row();progress=new ProgressBar(this);status.addView(progress,new LinearLayout.LayoutParams(dp(22),dp(22)));info=label("Import a photo to begin",11,muted);info.setPadding(dp(6),0,0,0);status.addView(info,new LinearLayout.LayoutParams(0,dp(36),1));root.addView(status);
  View divider=new View(this);divider.setBackgroundColor(0xffe5e7eb);root.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));
  for(String[] names:new String[][]{{"Pen","Text","Crop"},{"Blur","Unblur","Rotate"}}){LinearLayout menu=row();for(String name:names){Button b=button(name,v->choose(name));tools.put(name,b);menu.addView(b,cell(42));}root.addView(menu);}
  LinearLayout options=row();colorButton=button("Color",v->colors());options.addView(colorButton,new LinearLayout.LayoutParams(dp(76),dp(40)));options.addView(label("Size",12,muted));size=new SeekBar(this);size.setMax(58);size.setProgress(10);options.addView(size,new LinearLayout.LayoutParams(0,dp(38),1));TextView sizeLabel=label("12",12,textColor);options.addView(sizeLabel);size.setOnSeekBarChangeListener(listener(p->{editor.size=p+2;sizeLabel.setText(String.format(Locale.getDefault(),"%d",p+2));editor.invalidate();}));root.addView(options);
  anglePanel=row();anglePanel.addView(label("Straighten",12,muted));angleBar=new SeekBar(this);angleBar.setMax(300);angleBar.setProgress(150);anglePanel.addView(angleBar,new LinearLayout.LayoutParams(0,dp(38),1));angleValue=label("0.0°",12,textColor);anglePanel.addView(angleValue);angleBar.setOnSeekBarChangeListener(listener(p->{editor.angle=(p-150)/10f;editor.selected=Math.abs(editor.angle)>.01;angleValue.setText(String.format(Locale.getDefault(),"%.1f°",editor.angle));editor.signal();}));root.addView(anglePanel);
  LinearLayout bottom=row();undo=button("Undo",v->render(document.undo()));redo=button("Redo",v->render(document.redo()));cancel=button("Cancel",v->{editor.clear();update();});apply=button("Apply",v->editor.apply());for(Button b:new Button[]{undo,redo,cancel,apply})bottom.addView(b,cell(42));root.addView(bottom);
  update();if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0,this::leave);
 }
 interface IntAction{void accept(int value);}
 SeekBar.OnSeekBarChangeListener listener(IntAction action){return new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean user){if(user&&!busy)action.accept(p);}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}};}
 LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
 LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
 LinearLayout.LayoutParams cell(int height){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(height),1);p.setMargins(dp(3),dp(3),dp(3),dp(3));return p;}
 TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
 GradientDrawable shape(int fill,int border){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(10));d.setStroke(dp(1),border);return d;}
 Button button(String s,View.OnClickListener action){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setTextColor(textColor);b.setAllCaps(false);b.setMinWidth(0);b.setMinimumWidth(0);b.setPadding(dp(6),0,dp(6),0);b.setBackground(shape(Color.WHITE,0xffd0d5dd));b.setOnClickListener(v->{if(!busy)action.onClick(v);});buttons.add(b);return b;}
 void update(){if(editor==null||undo==null)return;for(Button b:buttons)b.setEnabled(!busy);editor.busy=busy;size.setEnabled(!busy);angleBar.setEnabled(!busy);progress.setVisibility(busy?View.VISIBLE:View.GONE);
  undo.setEnabled(!busy&&document!=null&&document.cursor>0);redo.setEnabled(!busy&&document!=null&&document.cursor<document.ops.size());apply.setEnabled(!busy&&editor.selected);cancel.setEnabled(!busy&&editor.selected);
  for(Map.Entry<String,Button> e:tools.entrySet()){boolean active=editor.tool.equals(e.getKey());e.getValue().setBackground(shape(active?0xfffff0e5:Color.WHITE,active?accent:0xffd0d5dd));e.getValue().setTextColor(active?accent:textColor);}
  colorButton.setBackground(shape(editor.color,0xffd0d5dd));colorButton.setTextColor(Color.luminance(editor.color)>.45?Color.BLACK:Color.WHITE);
  anglePanel.setVisibility(editor.tool.equals("Rotate")?View.VISIBLE:View.GONE);angleValue.setText(String.format(Locale.getDefault(),"%.1f°",editor.angle));
  String hint=editor.tool.equals("Text")?"Drag text, then Apply":editor.tool.equals("Crop")?"Drag corners / move box → Apply":editor.tool.equals("Blur")||editor.tool.equals("Unblur")?"Drag area; applies on release":editor.tool.equals("Rotate")?"Straighten slider → Apply":"Draw with your finger";
  info.setText(busy?"Processing… please wait":editor.ready()?hint:"Import a photo to begin");
  for(Button b:new Button[]{undo,redo,apply,cancel})b.setAlpha(b.isEnabled()?1f:.35f);
 }
 void setBusy(boolean value){busy=value;editor.busy=value;update();}
 void commit(EditDocument.Op op){if(document==null||busy)return;if(document.cursor>=500){toast("500 edits reached. Save and re-import to continue.");return;}render(document.add(op));}
 void render(EditDocument next){if(next==null||busy)return;setBusy(true);worker.execute(()->{try{Bitmap image=next.render();runOnUiThread(()->{if(isDestroyed())return;document=next;editor.show(image);setBusy(false);});}catch(Exception|OutOfMemoryError ex){runOnUiThread(()->{if(!isDestroyed()){editor.clear();setBusy(false);toast("Could not apply this edit. Try a smaller image.");}});}});}
 void choose(String t){if(!editor.ready()){toast("Import a photo first");return;}
  if(t.equals("Text")){EditText input=new EditText(this);input.setText(editor.text);input.setTextColor(textColor);input.setHint("Type text here");input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);input.setMinLines(2);input.setPadding(dp(18),dp(10),dp(18),dp(10));new AlertDialog.Builder(this).setTitle("Add text").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Preview",(d,w)->{String s=input.getText().toString().trim();if(!s.isEmpty())editor.startText(s);}).show();}
  else if(t.equals("Rotate")){editor.choose(t);angleBar.setProgress(150);new AlertDialog.Builder(this).setTitle("Rotate / straighten").setItems(new String[]{"Rotate left 90°","Rotate right 90°","Straighten with slider"},(d,w)->{if(w<2)commit(EditDocument.Op.rotate(w==0?-90:90));else{editor.choose("Rotate");angleBar.setProgress(150);update();}}).show();}
  else editor.choose(t);
 }
 void colors(){LinearLayout wrap=column();wrap.setPadding(dp(16),dp(8),dp(16),dp(8));TextView preview=label("Color",18,textColor);wrap.addView(preview);LinearLayout swatches=row();wrap.addView(swatches);int[] chosen={editor.color};ArrayList<SeekBar> sliders=new ArrayList<>();
  for(int color:new int[]{0xffe65900,0xffe52745,0xff00a66a,0xff187ae0,Color.BLACK,Color.WHITE}){Button b=new Button(this);b.setText("●");b.setTextColor(color);b.setTextSize(22);b.setMinWidth(0);b.setMinimumWidth(0);b.setPadding(0,0,0,0);b.setBackground(shape(Color.WHITE,0xffd0d5dd));b.setOnClickListener(v->{for(int i=0;i<3;i++)sliders.get(i).setProgress((color>>(16-i*8))&255);});swatches.addView(b,cell(40));}
  for(int i=0;i<3;i++){wrap.addView(label(new String[]{"Red","Green","Blue"}[i],12,muted));SeekBar bar=new SeekBar(this);bar.setMax(255);bar.setProgress((editor.color>>(16-i*8))&255);sliders.add(bar);wrap.addView(bar);}
  for(SeekBar bar:sliders)bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){chosen[0]=Color.rgb(sliders.get(0).getProgress(),sliders.get(1).getProgress(),sliders.get(2).getProgress());preview.setText(String.format(Locale.ROOT,"#%06X",chosen[0]&0xffffff));preview.setBackgroundColor(chosen[0]);preview.setTextColor(Color.luminance(chosen[0])>.45?Color.BLACK:Color.WHITE);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
  new AlertDialog.Builder(this).setTitle("Pen / text color").setView(wrap).setNegativeButton("Cancel",null).setPositiveButton("Use color",(d,w)->{editor.color=chosen[0];editor.invalidate();update();}).show();
 }
 void importAsk(){if(editor.ready())new AlertDialog.Builder(this).setTitle("Import another photo?").setMessage("Save your current image first. This starts a new session.").setNegativeButton("Cancel",null).setPositiveButton("Import",(d,w)->pick()).show();else pick();}
 void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,IMPORT);}
 void format(boolean share){if(!editor.ready()){toast("Import a photo first");return;}if(editor.selected){toast("Apply or cancel the preview first");return;}
  new AlertDialog.Builder(this).setTitle(share?"Share image":"Save image").setItems(new String[]{"PNG","JPEG • white background, 95%"},(d,w)->{jpeg=w==1;exportImage=editor.image;if(share)export(null,true,jpeg);else{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType(jpeg?"image/jpeg":"image/png");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE,"tv2u-image-"+System.currentTimeMillis()+(jpeg?".jpg":".png"));startActivityForResult(i,SAVE);}}).show();
 }
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
  if(request==SAVE){if(result==RESULT_OK&&data!=null)export(data.getData(),false,jpeg);else exportImage=null;return;}
  if(request!=IMPORT||result!=RESULT_OK||data==null||busy)return;Uri uri=data.getData();setBusy(true);worker.execute(()->{try{
   Bitmap b=ImageDecoder.decodeBitmap(ImageDecoder.createSource(getContentResolver(),uri),(decoder,details,source)->{float ratio=Math.min(1f,1920f/Math.max(details.getSize().getWidth(),details.getSize().getHeight()));decoder.setTargetSize(Math.max(1,Math.round(details.getSize().getWidth()*ratio)),Math.max(1,Math.round(details.getSize().getHeight()*ratio)));decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);});
   EditDocument doc=new EditDocument(b);Bitmap image=doc.render();runOnUiThread(()->{if(!isDestroyed()){document=doc;editor.show(image);editor.choose("Pen");setBusy(false);}});
  }catch(Exception|OutOfMemoryError e){runOnUiThread(()->{if(!isDestroyed()){setBusy(false);toast("Cannot open image. Try a smaller PNG/JPEG.");}});}});
 }
 void export(Uri uri,boolean share,boolean jpg){final Bitmap image=exportImage;exportImage=null;if(image==null){toast("Tap Save again");return;}setBusy(true);worker.execute(()->{Bitmap flattened=null;try{
  Bitmap output=image;if(jpg){flattened=EditDocument.blank(image);Canvas c=new Canvas(flattened);c.drawColor(Color.WHITE);c.drawBitmap(image,0,0,null);output=flattened;}
  File file=null;OutputStream stream;if(share){File dir=new File(getCacheDir(),"share");if(!dir.isDirectory()&&!dir.mkdirs())throw new IOException();File[] old=dir.listFiles();if(old!=null)for(File f:old)if(System.currentTimeMillis()-f.lastModified()>86400000L)f.delete();file=new File(dir,"image-"+System.currentTimeMillis()+(jpg?".jpg":".png"));stream=new FileOutputStream(file);}else stream=getContentResolver().openOutputStream(uri,"wt");
  if(stream==null)throw new IOException();try(OutputStream out=stream){if(!output.compress(jpg?Bitmap.CompressFormat.JPEG:Bitmap.CompressFormat.PNG,95,out))throw new IOException();}File shared=file;
  runOnUiThread(()->{if(isDestroyed())return;setBusy(false);if(share){Uri u=Uri.parse("content://"+getPackageName()+".share/"+shared.getName());Intent i=new Intent(Intent.ACTION_SEND);i.setType(jpg?"image/jpeg":"image/png");i.putExtra(Intent.EXTRA_STREAM,u);i.setClipData(ClipData.newRawUri("Edited image",u));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivity(Intent.createChooser(i,"Share image"));}catch(ActivityNotFoundException ex){toast("No share app available");}}else toast("Image saved");});
 }catch(Exception|OutOfMemoryError e){runOnUiThread(()->{if(!isDestroyed()){setBusy(false);toast("Could not save/share. Check storage and try again.");}});}finally{if(flattened!=null)flattened.recycle();}});}
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
 void leave(){if(busy){toast("Please wait for processing");return;}if(editor.selected){editor.clear();update();}else if(document!=null)new AlertDialog.Builder(this).setTitle("Leave editor?").setMessage("Save your image first. Unsaved edits will be lost.").setNegativeButton("Stay",null).setPositiveButton("Exit",(d,w)->finish()).show();else finish();}
 @Override public void onBackPressed(){leave();}
 @Override protected void onDestroy(){super.onDestroy();worker.shutdown();}
}
