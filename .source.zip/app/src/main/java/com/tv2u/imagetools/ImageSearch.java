package com.tv2u.imagetools;
import android.app.Activity;
import android.content.*;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Parcelable;
import java.util.*;

/** Hands images to installed search apps; web fallback lets the user choose a saved image. */
final class ImageSearch {
 static List<Intent> targets(Context context,Uri uri){
  Intent base=new Intent(Intent.ACTION_SEND).setType("image/png");List<Intent> matches=new ArrayList<>();Set<String> seen=new HashSet<>();
  for(ResolveInfo r:context.getPackageManager().queryIntentActivities(base,0)){
   String pkg=r.activityInfo.packageName,name=String.valueOf(r.loadLabel(context.getPackageManager())).toLowerCase(Locale.ROOT);
   if(pkg.equals("com.google.ar.lens")||pkg.equals("com.google.android.googlequicksearchbox")||name.contains("lens")||name.contains("image search")||name.contains("visual search")){
    if(!seen.add(pkg+"/"+r.activityInfo.name))continue;
    Intent target=new Intent(base).setComponent(new ComponentName(pkg,r.activityInfo.name));
    if(uri!=null){target.putExtra(Intent.EXTRA_STREAM,uri);target.setClipData(ClipData.newRawUri("Image search",uri));target.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);}matches.add(target);
   }
  }return matches;
 }
 static boolean hasTarget(Context context){return !targets(context,null).isEmpty();}
 static boolean launch(Activity activity,Uri uri){List<Intent> list=targets(activity,uri);if(list.isEmpty())return false;Intent chooser=Intent.createChooser(list.get(0),"Search image with Lens / search app");if(list.size()>1)chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS,list.subList(1,list.size()).toArray(new Parcelable[0]));try{activity.startActivity(chooser);return true;}catch(ActivityNotFoundException e){return false;}}
 static void openWeb(Activity activity){try{activity.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://lens.google/")));}catch(ActivityNotFoundException ignored){}}
}
