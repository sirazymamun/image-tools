package com.tv2u.imagetools;

import android.app.Activity;
import android.content.Context;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.os.*;
import android.print.*;
import android.widget.Toast;
import java.io.*;
import java.util.concurrent.*;

/** Android system print sheet also provides Save as PDF. No public upload. */
final class ImagePrinter {
 static void print(Activity activity,Bitmap image){
  PrintManager manager=(PrintManager)activity.getSystemService(Context.PRINT_SERVICE);
  if(manager==null){Toast.makeText(activity,"Printing unavailable on this device",Toast.LENGTH_LONG).show();return;}
  manager.print("tv2u-image",new PrintDocumentAdapter(){
   final ExecutorService io=Executors.newSingleThreadExecutor();PrintAttributes attributes;
   @Override public void onLayout(PrintAttributes old,PrintAttributes next,CancellationSignal signal,LayoutResultCallback callback,Bundle extras){
    attributes=next;if(signal.isCanceled()){callback.onLayoutCancelled();return;}
    callback.onLayoutFinished(new PrintDocumentInfo.Builder("tv2u-image.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_PHOTO).setPageCount(1).build(),old==null||!next.equals(old));
   }
   @Override public void onWrite(PageRange[] pages,ParcelFileDescriptor destination,CancellationSignal signal,WriteResultCallback callback){
    boolean wanted=false;for(PageRange range:pages)if(range.getStart()==0)wanted=true;if(!wanted){callback.onWriteFinished(new PageRange[0]);return;}
    io.execute(()->{
     PdfDocument pdf=new PdfDocument();
     try{
      if(signal.isCanceled()){callback.onWriteCancelled();return;}
      PrintAttributes.MediaSize media=attributes==null?null:attributes.getMediaSize();int w=media==null?595:Math.max(1,media.getWidthMils()*72/1000),h=media==null?842:Math.max(1,media.getHeightMils()*72/1000);
      PrintAttributes.Margins margins=attributes==null?null:attributes.getMinMargins();float left=margins==null?24:margins.getLeftMils()*72/1000f,top=margins==null?24:margins.getTopMils()*72/1000f,right=margins==null?24:margins.getRightMils()*72/1000f,bottom=margins==null?24:margins.getBottomMils()*72/1000f;
      PdfDocument.Page page=pdf.startPage(new PdfDocument.PageInfo.Builder(w,h,1).create());Canvas canvas=page.getCanvas();canvas.drawColor(Color.WHITE);
      float scale=Math.min(Math.max(1,w-left-right)/image.getWidth(),Math.max(1,h-top-bottom)/image.getHeight());float x=left+(w-left-right-image.getWidth()*scale)/2,y=top+(h-top-bottom-image.getHeight()*scale)/2;
      canvas.drawBitmap(image,null,new RectF(x,y,x+image.getWidth()*scale,y+image.getHeight()*scale),new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG));pdf.finishPage(page);
      if(signal.isCanceled()){callback.onWriteCancelled();return;}
      try(FileOutputStream out=new FileOutputStream(destination.getFileDescriptor())){pdf.writeTo(out);}
      if(signal.isCanceled())callback.onWriteCancelled();else callback.onWriteFinished(new PageRange[]{new PageRange(0,0)});
     }catch(Exception|OutOfMemoryError e){callback.onWriteFailed("Could not prepare image for printing");}finally{pdf.close();}
    });
   }
   @Override public void onFinish(){io.shutdown();}
  },new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setColorMode(PrintAttributes.COLOR_MODE_COLOR).build());
 }
}
