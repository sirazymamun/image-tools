package com.tv2u.imagetools;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.*;
/** One beveled metal strip; controls are transparent until touched/selected. */
final class ToolbarSkin {
 static GradientDrawable bar(boolean vertical,float density){GradientDrawable d=new GradientDrawable(vertical?GradientDrawable.Orientation.LEFT_RIGHT:GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0xfffafbfc,0xffe5e8eb,0xffccd1d5});d.setCornerRadius(3*density);d.setStroke(Math.max(1,Math.round(density)),0xff9da5ac);return d;}
 static Drawable button(boolean selected,float density){GradientDrawable content=new GradientDrawable();content.setColor(selected?0xffffe3c7:Color.TRANSPARENT);content.setCornerRadius(2*density);if(selected)content.setStroke(Math.max(1,Math.round(density)),0xffb97738);return new RippleDrawable(ColorStateList.valueOf(0x443e5265),content,null);}
}
