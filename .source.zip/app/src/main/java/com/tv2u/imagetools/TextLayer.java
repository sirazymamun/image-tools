package com.tv2u.imagetools;
import android.graphics.*;
import java.util.*;
/** Editable app-added text, with the transforms applied after its creation. */
final class TextLayer {
 final int index,width,height;final EditDocument.Op op;final Matrix transform=new Matrix();
 TextLayer(int index,EditDocument.Op op,int w,int h){this.index=index;this.op=op;width=w;height=h;}
 static RectF bounds(String text,float x,float y,float size){Paint p=new Paint(3);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(size);float w=0;String[] lines=text.split("\n",-1);for(String line:lines)w=Math.max(w,p.measureText(line));return new RectF(x,y+p.ascent(),x+Math.max(8,w),y+(lines.length-1)*size*1.25f+p.descent());}
 boolean contains(float x,float y,float reach){Matrix inverse=new Matrix();if(!transform.invert(inverse))return false;float[] point={x,y};inverse.mapPoints(point);RectF r=bounds(op.text,op.x,op.y,op.size);float padding=reach/Math.max(.01f,transform.mapRadius(1));r.inset(-padding,-padding);return r.contains(point[0],point[1]);}
 static List<TextLayer> from(EditDocument doc){List<TextLayer> layers=new ArrayList<>();Map<Integer,EditDocument.Op> overrides=doc.textOverrides();int w=doc.source.getWidth(),h=doc.source.getHeight();
  for(int i=0;i<doc.cursor;i++){EditDocument.Op op=overrides.containsKey(i)?overrides.get(i):doc.ops.get(i);Matrix step=new Matrix();boolean geometry=false;
   switch(op.type){
    case "Text":layers.add(new TextLayer(i,op,w,h));break;
    case "Reset":layers.clear();w=doc.source.getWidth();h=doc.source.getHeight();break;
    case "Crop":step.setTranslate(-op.rect.left,-op.rect.top);w=op.rect.width();h=op.rect.height();geometry=true;break;
    case "Rotate":step.setRotate(op.angle);RectF box=new RectF(0,0,w,h);step.mapRect(box);step.postTranslate(-box.left,-box.top);w=Math.max(1,Math.round(box.width()));h=Math.max(1,Math.round(box.height()));geometry=true;break;
    case "Perspective":int[] size=PerspectiveWarp.outputSize(op.points);step.setPolyToPoly(op.points,0,new float[]{0,0,size[0],0,size[0],size[1],0,size[1]},0,4);w=size[0];h=size[1];geometry=true;break;
    default:break;
   }
   if(geometry)for(TextLayer layer:layers)layer.transform.postConcat(step);
  }return layers;
 }
}
