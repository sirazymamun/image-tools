package com.tv2u.imagetools;
import android.graphics.*;
import android.view.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=29,manifest=Config.NONE)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class PerspectiveWarpTest {
 @Test public void rejectsCrossedOrCollapsedCorners(){assertFalse(PerspectiveWarp.valid(new float[]{0,0,100,100,100,0,0,100}));assertFalse(PerspectiveWarp.valid(new float[]{0,0,0,0,100,100,0,100}));assertTrue(PerspectiveWarp.valid(new float[]{10,10,150,25,120,120,0,100}));}
 @Test public void outputSizePreservesRectangularSelection(){int[] size=PerspectiveWarp.outputSize(new float[]{20,30,220,30,220,130,20,130});assertArrayEquals(new int[]{200,100},size);}
 @Test public void trapezoidBecomesStraightRectangleWithCorrectCornerColors(){
  Bitmap board=Bitmap.createBitmap(200,150,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(board);Paint p=new Paint();p.setColor(Color.RED);canvas.drawRect(0,0,100,75,p);p.setColor(Color.GREEN);canvas.drawRect(100,0,200,75,p);p.setColor(Color.BLUE);canvas.drawRect(100,75,200,150,p);p.setColor(Color.YELLOW);canvas.drawRect(0,75,100,150,p);
  float[] q={60,20,360,60,320,260,20,240};Matrix toQuad=new Matrix();assertTrue(toQuad.setPolyToPoly(new float[]{0,0,200,0,200,150,0,150},0,q,0,4));Bitmap src=Bitmap.createBitmap(400,300,Bitmap.Config.ARGB_8888);new Canvas(src).drawBitmap(board,toQuad,new Paint(3));Bitmap out=PerspectiveWarp.warp(src,q);int w=out.getWidth(),h=out.getHeight();assertEquals(Color.RED,out.getPixel(w/4,h/4));assertEquals(Color.GREEN,out.getPixel(w*3/4,h/4));assertEquals(Color.BLUE,out.getPixel(w*3/4,h*3/4));assertEquals(Color.YELLOW,out.getPixel(w/4,h*3/4));
 }
 @Test public void perspectiveCropSupportsUndoRedoAndLaterAnnotations(){Bitmap src=Bitmap.createBitmap(240,180,Bitmap.Config.ARGB_8888);src.eraseColor(Color.WHITE);EditDocument d=new EditDocument(src).add(EditDocument.Op.perspective(new float[]{20,10,220,20,210,160,10,150}));Bitmap cropped=d.render();assertEquals(240,d.undo().render().getWidth());assertTrue(d.undo().redo().render().sameAs(cropped));Path pen=new Path();pen.moveTo(10,40);pen.lineTo(80,40);assertEquals(Color.RED,d.add(EditDocument.Op.pen(pen,6,Color.RED)).render().getPixel(40,40));}
 @Test public void draggingOneCornerDoesNotMoveOtherCorners(){EditorView v=new EditorView(RuntimeEnvironment.getApplication());v.show(Bitmap.createBitmap(200,150,Bitmap.Config.ARGB_8888));v.layout(0,0,400,400);v.draw(new Canvas(Bitmap.createBitmap(400,400,Bitmap.Config.ARGB_8888)));v.choose("Perspective");float[] before=v.quad.clone();touch(v,MotionEvent.ACTION_DOWN,before[0],before[1]);touch(v,MotionEvent.ACTION_MOVE,before[0]+8,before[1]+9);touch(v,MotionEvent.ACTION_UP,before[0]+8,before[1]+9);assertEquals(before[0]+8,v.quad[0],.1f);assertEquals(before[1]+9,v.quad[1],.1f);for(int i=2;i<8;i++)assertEquals(before[i],v.quad[i],.1f);assertTrue(v.selected);}
 @Test public void penWidthSupportsOnePixelAndWideStrokes(){Paint thin=DrawingTools.paint("Pen",1,Color.RED),thick=DrawingTools.paint("Pen",60,Color.RED);assertEquals(1,thin.getStrokeWidth(),0);assertEquals(60,thick.getStrokeWidth(),0);}
 void touch(EditorView v,int action,float x,float y){MotionEvent e=MotionEvent.obtain(0,0,action,v.display.left+x*v.scale,v.display.top+y*v.scale,0);v.onTouchEvent(e);e.recycle();}
}
