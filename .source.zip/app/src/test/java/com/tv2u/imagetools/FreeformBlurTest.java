package com.tv2u.imagetools;
import android.graphics.*;
import android.view.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;
import java.util.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=29,manifest=Config.NONE)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class FreeformBlurTest {
 Bitmap stripes(){Bitmap b=Bitmap.createBitmap(96,96,Bitmap.Config.ARGB_8888);for(int y=0;y<96;y++)for(int x=0;x<96;x++)b.setPixel(x,y,x%2==0?Color.BLACK:Color.WHITE);return b;}
 Path triangle(){Path p=new Path();p.moveTo(10,10);p.lineTo(85,10);p.lineTo(10,85);p.close();return p;}
 @Test public void blurFollowsFreeformBoundaryInsteadOfItsBoundingRectangle(){Bitmap source=stripes();EditDocument d=new EditDocument(source).add(EditDocument.Op.freeform("Blur",triangle()));Bitmap blurred=d.render();assertNotEquals(source.getPixel(30,30),blurred.getPixel(30,30));assertEquals(source.getPixel(75,75),blurred.getPixel(75,75));assertEquals(source.getPixel(3,3),blurred.getPixel(3,3));}
 @Test public void freeformUnblurRestoresOnlySelectedSourceAreaAndSupportsUndo(){Bitmap source=stripes();EditDocument blurred=new EditDocument(source).add(EditDocument.Op.freeform("Blur",triangle()));Path area=new Path();area.addCircle(30,30,8,Path.Direction.CW);EditDocument clear=blurred.add(EditDocument.Op.freeform("Unblur",area));Bitmap output=clear.render();assertEquals(source.getPixel(30,30),output.getPixel(30,30));assertEquals(blurred.render().getPixel(55,25),output.getPixel(55,25));assertTrue(clear.undo().render().sameAs(blurred.render()));assertTrue(clear.undo().redo().render().sameAs(output));}
 @Test public void freeformMaskSurvivesCropRotationAndRestoresTransformedSource(){Bitmap source=stripes();EditDocument plain=new EditDocument(source).add(EditDocument.Op.region("Crop",new Rect(8,8,88,88))).add(EditDocument.Op.rotate(90));EditDocument d=new EditDocument(source).add(EditDocument.Op.freeform("Blur",triangle())).add(EditDocument.Op.region("Crop",new Rect(8,8,88,88))).add(EditDocument.Op.rotate(90));Path area=new Path();area.addCircle(58,22,8,Path.Direction.CW);Bitmap restored=d.add(EditDocument.Op.freeform("Unblur",area)).render();assertEquals(plain.render().getPixel(58,22),restored.getPixel(58,22));assertEquals(80,restored.getWidth());}
 EditorView view(){EditorView v=new EditorView(RuntimeEnvironment.getApplication());v.show(stripes());v.layout(0,0,300,600);v.choose("Blur");v.updateViewport();return v;}
 void touch(EditorView v,int action,float x,float y){float[] point={x,y};v.imageToView.mapPoints(point);MotionEvent e=MotionEvent.obtain(0,0,action,point[0],point[1],0);v.onTouchEvent(e);e.recycle();}
 void select(EditorView v){touch(v,MotionEvent.ACTION_DOWN,10,10);touch(v,MotionEvent.ACTION_MOVE,85,10);touch(v,MotionEvent.ACTION_MOVE,10,85);touch(v,MotionEvent.ACTION_UP,10,10);}
 Region region(Path p){Region r=new Region();r.setPath(p,new Region(0,0,96,96));return r;}
 @Test public void lassoSelectionWaitsForApplyAndCancelUndoDoNotEditImage(){EditorView v=view();List<EditDocument.Op> ops=new ArrayList<>();v.commit=ops::add;select(v);assertTrue(v.selected);assertTrue(ops.isEmpty());assertTrue(region(v.lassoPath).contains(30,30));assertFalse(region(v.lassoPath).contains(75,75));assertTrue(v.undoPreview());assertFalse(v.selected);select(v);v.clear();assertFalse(v.selected);assertTrue(ops.isEmpty());select(v);v.apply();assertEquals(1,ops.size());assertNotNull(ops.get(0).path);}
 @Test public void pinchPreservesExistingLassoWithoutCommittingIt(){EditorView v=view();select(v);Region original=region(v.lassoPath);List<EditDocument.Op> ops=new ArrayList<>();v.commit=ops::add;MotionEvent down=MotionEvent.obtain(0,0,MotionEvent.ACTION_DOWN,100,280,0);v.onTouchEvent(down);down.recycle();ViewportTest events=new ViewportTest();events.multi(v,MotionEvent.ACTION_POINTER_DOWN|(1<<MotionEvent.ACTION_POINTER_INDEX_SHIFT),100,280,200,280);events.multi(v,MotionEvent.ACTION_MOVE,80,300,220,300);MotionEvent up=MotionEvent.obtain(0,30,MotionEvent.ACTION_UP,80,300,0);v.onTouchEvent(up);up.recycle();assertEquals(original,region(v.lassoPath));assertTrue(v.selected);assertTrue(ops.isEmpty());}
 @Test public void degenerateLineCannotBeApplied(){EditorView v=view();touch(v,MotionEvent.ACTION_DOWN,10,10);touch(v,MotionEvent.ACTION_MOVE,70,70);touch(v,MotionEvent.ACTION_UP,70,70);assertFalse(v.selected);}
 @Test public void visibleToolsApplyAndReturnToMove() throws Exception {try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).setup()){MainActivity a=c.get();new FloatingLayoutTest().load(a);new FloatingLayoutTest().layout(a,411,891);assertTrue(a.tools.containsKey("Blur"));assertTrue(a.tools.containsKey("Unblur"));a.tools.get("Blur").performClick();select(a.editor);assertEquals(View.VISIBLE,a.selectionActions.getVisibility());assertTrue(a.undo.isEnabled());int cursor=a.document.cursor;a.apply.performClick();new EditableTextTest().finish(a);assertEquals(cursor+1,a.document.cursor);assertEquals("Blur",a.document.ops.get(cursor).type);assertNotNull(a.document.ops.get(cursor).path);assertEquals("Move",a.editor.tool);a.choose("Unblur");select(a.editor);a.cancel.performClick();assertEquals(cursor+1,a.document.cursor);assertEquals("Move",a.editor.tool);}}
 @Test @Config(sdk=26) public void freeformBlurWorksOnAndroid8(){Bitmap source=stripes();Bitmap out=new EditDocument(source).add(EditDocument.Op.freeform("Blur",triangle())).render();assertNotEquals(source.getPixel(30,30),out.getPixel(30,30));assertEquals(source.getPixel(75,75),out.getPixel(75,75));}
}
