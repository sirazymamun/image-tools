package com.tv2u.imagetools;
import android.graphics.*;
import android.view.MotionEvent;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import java.util.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=29,manifest=Config.NONE)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class EditorGestureTest {
 EditorView view(){EditorView v=new EditorView(RuntimeEnvironment.getApplication());v.show(Bitmap.createBitmap(200,100,Bitmap.Config.ARGB_8888));v.layout(0,0,400,400);v.draw(new Canvas(Bitmap.createBitmap(400,400,Bitmap.Config.ARGB_8888)));return v;}
 void touch(EditorView v,int action,float x,float y){MotionEvent e=MotionEvent.obtain(0,0,action,v.display.left+x*v.scale,v.display.top+y*v.scale,0);v.onTouchEvent(e);e.recycle();}
 @Test public void blurCommitsOnRelease(){EditorView v=view();List<EditDocument.Op> ops=new ArrayList<>();v.commit=ops::add;v.choose("Blur");touch(v,MotionEvent.ACTION_DOWN,20,20);touch(v,MotionEvent.ACTION_MOVE,80,70);assertTrue(ops.isEmpty());touch(v,MotionEvent.ACTION_UP,80,70);assertEquals(1,ops.size());assertEquals("Blur",ops.get(0).type);assertTrue(ops.get(0).rect.contains(50,40));}
 @Test public void textPreviewCommitsOnlyOnApply(){EditorView v=view();List<EditDocument.Op> ops=new ArrayList<>();v.commit=ops::add;v.startText("Hi");float oldX=v.textX;assertTrue(v.selected);touch(v,MotionEvent.ACTION_DOWN,20,65);touch(v,MotionEvent.ACTION_UP,20,65);assertTrue(ops.isEmpty());v.apply();assertEquals(1,ops.size());assertEquals("Hi",ops.get(0).text);assertEquals(oldX,ops.get(0).x,.1f);}
 @Test public void busyCanvasRejectsGestures(){EditorView v=view();List<EditDocument.Op> ops=new ArrayList<>();v.commit=ops::add;v.choose("Pen");v.busy=true;touch(v,MotionEvent.ACTION_DOWN,20,20);touch(v,MotionEvent.ACTION_UP,80,70);assertTrue(ops.isEmpty());}
 @Test public void cropWaitsForApply(){EditorView v=view();List<EditDocument.Op> ops=new ArrayList<>();v.commit=ops::add;v.choose("Crop");assertTrue(v.selected);v.apply();assertEquals("Crop",ops.get(0).type);}
}
