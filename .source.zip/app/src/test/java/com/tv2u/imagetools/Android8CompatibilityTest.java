package com.tv2u.imagetools;
import android.graphics.*;
import android.media.ExifInterface;
import android.net.Uri;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import java.io.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=26,manifest=Config.NONE)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class Android8CompatibilityTest {
 @Test public void activityAndExtraToolsInitializeOnAndroid8(){try(org.robolectric.android.controller.ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).setup()){MainActivity a=c.get();assertEquals(9,a.tools.size());assertTrue(a.tools.containsKey("Perspective"));assertTrue(a.tools.containsKey("Straighten"));}}
 @Test public void pngImportWorksOnAndroid8AndDownsamples() throws Exception {File file=new File(RuntimeEnvironment.getApplication().getCacheDir(),"compat-large.png");Bitmap b=Bitmap.createBitmap(2400,1200,Bitmap.Config.ARGB_8888);b.eraseColor(Color.CYAN);try(FileOutputStream out=new FileOutputStream(file)){b.compress(Bitmap.CompressFormat.PNG,100,out);}Bitmap loaded=ImageLoader.load(RuntimeEnvironment.getApplication().getContentResolver(),Uri.fromFile(file));assertEquals(1920,loaded.getWidth());assertEquals(960,loaded.getHeight());assertEquals(Color.CYAN,loaded.getPixel(300,300));}
 @Test public void exifRotationAndMirroringUseLegacySafeMatrix(){Bitmap b=Bitmap.createBitmap(100,50,Bitmap.Config.ARGB_8888);b.eraseColor(Color.WHITE);b.setPixel(0,0,Color.RED);Bitmap rotated=ImageLoader.orient(b,ExifInterface.ORIENTATION_ROTATE_90);assertEquals(50,rotated.getWidth());assertEquals(100,rotated.getHeight());Bitmap flipped=ImageLoader.orient(b,ExifInterface.ORIENTATION_FLIP_HORIZONTAL);assertEquals(Color.RED,flipped.getPixel(99,0));}
 @Test public void perspectiveAndThinPenWorkOnAndroid8(){Bitmap b=Bitmap.createBitmap(200,120,Bitmap.Config.ARGB_8888);b.eraseColor(Color.WHITE);EditDocument d=new EditDocument(b).add(EditDocument.Op.perspective(new float[]{10,5,190,10,180,110,5,100}));assertTrue(d.render().getWidth()>100);assertEquals(1,DrawingTools.paint("Pen",1,Color.RED).getStrokeWidth(),0);}
}
