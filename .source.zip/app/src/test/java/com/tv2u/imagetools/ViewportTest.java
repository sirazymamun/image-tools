package com.tv2u.imagetools;
import android.graphics.*;
import android.view.MotionEvent;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import java.util.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=29,manifest=Config.NONE)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class ViewportTest {
 EditorView view(int iw,int ih,int w,int h){EditorView v=new EditorView(RuntimeEnvironment.getApplication());Bitmap b=Bitmap.createBitmap(iw,ih,Bitmap.Config.ARGB_8888);b.eraseColor(Color.CYAN);v.show(b);v.layout(0,0,w,h);v.updateViewport();return v;}
 @Test public void fillHasNoLetterboxInPortraitLandscapeOrStraighten(){for(int[] dimensions:new int[][]{{120,200,320,700},{200,120,700,320},{200,120,320,700}}){EditorView v=view(dimensions[0],dimensions[1],dimensions[2],dimensions[3]);for(float angle:new float[]{0,-15,15}){v.angle=angle;v.updateViewport();float[] points={0,0,v.getWidth(),0,v.getWidth(),v.getHeight(),0,v.getHeight()};v.viewToImage.mapPoints(points);for(int i=0;i<8;i+=2){assertTrue(points[i]>=-.01&&points[i]<=v.image.getWidth()+.01);assertTrue(points[i+1]>=-.01&&points[i+1]<=v.image.getHeight()+.01);}Bitmap frame=Bitmap.createBitmap(v.getWidth(),v.getHeight(),Bitmap.Config.ARGB_8888);v.draw(new Canvas(frame));assertEquals(Color.CYAN,frame.getPixel(2,2));}}}
 @Test public void panIsClampedAndDoesNotCropExport(){EditorView v=view(400,200,200,600);Bitmap original=v.image.copy(Bitmap.Config.ARGB_8888,false);v.centerX=-10000;v.centerY=10000;v.updateViewport();assertTrue(v.centerX>0);assertTrue(v.centerY<=200);assertTrue(v.display.left<=0);assertTrue(v.display.right>=200);EditDocument doc=new EditDocument(v.image);Bitmap saved=doc.render();assertEquals(400,saved.getWidth());assertEquals(200,saved.getHeight());assertTrue(original.sameAs(saved));}
 @Test public void transformRoundTripMatchesInkAfterZoomAndPan(){EditorView v=view(400,200,200,600);v.zoom=2;v.centerX=120;v.centerY=90;v.updateViewport();float[] at={125,95};v.imageToView.mapPoints(at);float[] actual=v.sourcePoint(at[0],at[1]);assertEquals(125,actual[0],.001);assertEquals(95,actual[1],.001);}
 void multi(EditorView v,int action,float x0,float y0,float x1,float y1){MotionEvent.PointerProperties[] properties={new MotionEvent.PointerProperties(),new MotionEvent.PointerProperties()};MotionEvent.PointerCoords[] coords={new MotionEvent.PointerCoords(),new MotionEvent.PointerCoords()};for(int i=0;i<2;i++){properties[i].id=i;properties[i].toolType=MotionEvent.TOOL_TYPE_FINGER;coords[i].pressure=1;coords[i].size=1;}coords[0].x=x0;coords[0].y=y0;coords[1].x=x1;coords[1].y=y1;MotionEvent e=MotionEvent.obtain(0,20,action,2,properties,coords,0,0,1,1,0,0,0,0);v.onTouchEvent(e);e.recycle();}
 @Test public void twoFingerPinchCancelsInkAndLeavesDocumentUntouched(){EditorView v=view(400,200,300,600);List<EditDocument.Op> ops=new ArrayList<>();v.commit=ops::add;MotionEvent down=MotionEvent.obtain(0,0,MotionEvent.ACTION_DOWN,120,200,0);v.onTouchEvent(down);down.recycle();multi(v,MotionEvent.ACTION_POINTER_DOWN|(1<<MotionEvent.ACTION_POINTER_INDEX_SHIFT),100,200,200,200);multi(v,MotionEvent.ACTION_MOVE,60,240,260,240);assertEquals(2,v.zoom,.01);assertFalse(v.drawing);MotionEvent up=MotionEvent.obtain(0,30,MotionEvent.ACTION_UP,60,240,0);v.onTouchEvent(up);up.recycle();assertFalse(v.navigating);assertTrue(ops.isEmpty());}
}
