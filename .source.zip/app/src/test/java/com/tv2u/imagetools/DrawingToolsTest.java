package com.tv2u.imagetools;
import android.graphics.*;
import android.view.MotionEvent;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import java.util.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=29,manifest=Config.NONE)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class DrawingToolsTest {
 Bitmap white(){Bitmap b=Bitmap.createBitmap(200,160,Bitmap.Config.ARGB_8888);b.eraseColor(Color.WHITE);return b;}
 EditDocument stroke(String tool,float x1,float y1,float x2,float y2,int width){return new EditDocument(white()).add(EditDocument.Op.stroke(tool,DrawingTools.shapePath(tool,x1,y1,x2,y2,width),width,Color.RED));}
 @Test public void arrowHasShaftAndTwoVisibleHeadWings(){Bitmap b=stroke("Arrow",20,80,160,80,4).render();assertEquals(Color.RED,b.getPixel(90,80));assertTrue(Color.green(b.getPixel(145,72))<200);assertTrue(Color.green(b.getPixel(145,88))<200);assertEquals(Color.WHITE,b.getPixel(50,20));}
 @Test public void leftFacingArrowKeepsHeadAtEnd(){Bitmap b=stroke("Arrow",160,80,20,80,4).render();assertEquals(Color.RED,b.getPixel(90,80));assertTrue(Color.green(b.getPixel(35,72))<200);assertEquals(Color.WHITE,b.getPixel(145,72));}
 @Test public void rectangleHasOutlineAndUnfilledCenter(){Bitmap b=stroke("Rectangle",140,120,20,20,4).render();assertEquals(Color.RED,b.getPixel(80,20));assertEquals(Color.RED,b.getPixel(20,60));assertEquals(Color.WHITE,b.getPixel(80,60));}
 @Test public void lineHasNoArrowhead(){Bitmap b=stroke("Line",20,80,160,80,4).render();assertEquals(Color.RED,b.getPixel(80,80));assertEquals(Color.WHITE,b.getPixel(145,72));}
 @Test public void markerIsTranslucentAndUndoRedoWorks(){Path p=new Path();p.moveTo(20,80);p.lineTo(160,80);EditDocument d=new EditDocument(white()).add(EditDocument.Op.stroke("Marker",p,6,Color.RED));int color=d.render().getPixel(80,80);assertEquals(255,Color.red(color));assertTrue(Color.green(color)>100&&Color.green(color)<230);assertEquals(Color.WHITE,d.undo().render().getPixel(80,80));assertEquals(color,d.undo().redo().render().getPixel(80,80));}
 @Test public void arrowGestureCommitsItsDirectionOnlyOnRelease(){EditorView v=new EditorView(RuntimeEnvironment.getApplication());v.show(white());v.layout(0,0,400,400);v.draw(new Canvas(Bitmap.createBitmap(400,400,Bitmap.Config.ARGB_8888)));List<EditDocument.Op> ops=new ArrayList<>();v.commit=ops::add;v.choose("Arrow");touch(v,MotionEvent.ACTION_DOWN,20,80);touch(v,MotionEvent.ACTION_MOVE,160,80);assertTrue(ops.isEmpty());touch(v,MotionEvent.ACTION_UP,160,80);assertEquals(1,ops.size());assertEquals("Arrow",ops.get(0).type);Bitmap image=new EditDocument(white()).add(ops.get(0)).render();assertTrue(Color.green(image.getPixel(145,72))<240);}
 @Test public void shortArrowDoesNotExtendBehindStart(){Path p=DrawingTools.shapePath("Arrow",10,10,14,10,12);RectF bounds=new RectF();p.computeBounds(bounds,true);assertTrue(bounds.left>=10);assertTrue(bounds.right<=14);}
 @Test public void allToolbarIconsDrawWithoutFontGlyphs(){for(String name:new String[]{"Pen","Line","Arrow","Rectangle","Marker","Text","Blur","Unblur","Crop","Rotate","Copy","Save","Share","Undo","Redo","Print","Close","More","Upload","Search","Straighten","Perspective"}){ToolIcon icon=new ToolIcon(name);icon.setBounds(0,0,48,48);Bitmap b=Bitmap.createBitmap(48,48,Bitmap.Config.ARGB_8888);icon.draw(new Canvas(b));boolean found=false;for(int y=0;y<48;y++)for(int x=0;x<48;x++)found|=Color.alpha(b.getPixel(x,y))>0;assertTrue(name+" icon must be visible",found);}}
 void touch(EditorView v,int action,float x,float y){MotionEvent e=MotionEvent.obtain(0,0,action,v.display.left+x*v.scale,v.display.top+y*v.scale,0);v.onTouchEvent(e);e.recycle();}
}
