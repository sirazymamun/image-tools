package com.tv2u.imagetools;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.*;
import android.net.Uri;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowAlertDialog;
import java.io.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=26,manifest=Config.NONE)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class OpenWithTest {
 Uri png(int color) throws Exception {File f=File.createTempFile("open-with-",".png",RuntimeEnvironment.getApplication().getCacheDir());Bitmap b=Bitmap.createBitmap(120,80,Bitmap.Config.ARGB_8888);b.eraseColor(color);try(FileOutputStream out=new FileOutputStream(f)){b.compress(Bitmap.CompressFormat.PNG,100,out);}return Uri.fromFile(f);}
 Intent view(Uri uri){return new Intent(Intent.ACTION_VIEW).setDataAndType(uri,"image/png").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);}
 @Test public void viewIntentImportsImageInMoveModeOnAndroid8() throws Exception {try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class,view(png(Color.CYAN))).setup()){MainActivity a=c.get();new EditableTextTest().finish(a);assertNotNull(a.document);assertEquals(Color.CYAN,a.editor.image.getPixel(30,30));assertEquals("Move",a.editor.tool);assertFalse(a.editor.selected);assertEquals(0,a.document.cursor);}}
 @Test @Config(sdk=29) public void viewIntentImportsImageOnNewerDecoder() throws Exception {try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class,view(png(Color.GREEN))).setup()){MainActivity a=c.get();new EditableTextTest().finish(a);assertNotNull(a.document);assertEquals(Color.GREEN,a.editor.image.getPixel(30,30));assertEquals("Move",a.editor.tool);}}
 @Test public void existingSessionIsPreservedWhenNewImageIsCanceled() throws Exception {try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).setup()){MainActivity a=c.get();new FloatingLayoutTest().load(a);EditDocument original=a.document;a.onNewIntent(view(png(Color.RED)));AlertDialog confirm=ShadowAlertDialog.getLatestAlertDialog();assertTrue(confirm.isShowing());assertSame(original,a.document);confirm.getButton(AlertDialog.BUTTON_NEGATIVE).performClick();assertSame(original,a.document);a.onNewIntent(view(png(Color.BLUE)));ShadowAlertDialog.getLatestAlertDialog().getButton(AlertDialog.BUTTON_POSITIVE).performClick();Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();new EditableTextTest().finish(a);assertNotSame(original,a.document);assertEquals(Color.BLUE,a.editor.image.getPixel(30,30));assertEquals("Move",a.editor.tool);}}
 @Test public void incomingImagesAcceptContentUrisAndRejectUnrelatedIntents(){Uri content=Uri.parse("content://files/images/7");assertEquals(content,MainActivity.incomingImage(view(content)));assertNull(MainActivity.incomingImage(new Intent(Intent.ACTION_MAIN)));assertNull(MainActivity.incomingImage(new Intent(Intent.ACTION_VIEW).setDataAndType(content,"text/plain")));assertNull(MainActivity.incomingImage(view(Uri.parse("https://example.com/photo.png"))));}
}
