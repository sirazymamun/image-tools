package com.tv2u.imagetools;
import android.graphics.*;
import android.view.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;
import java.util.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=29,manifest=Config.NONE)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class MoveAndApplyTest {
 EditorView view(){EditorView v=new EditorView(RuntimeEnvironment.getApplication());Bitmap b=Bitmap.createBitmap(400,240,Bitmap.Config.ARGB_8888);b.eraseColor(Color.WHITE);v.show(b);v.layout(0,0,300,600);v.updateViewport();return v;}
 void touch(EditorView v,int action,float x,float y){MotionEvent e=MotionEvent.obtain(0,0,action,x,y,0);v.onTouchEvent(e);e.recycle();}
 void stroke(EditorView v){touch(v,MotionEvent.ACTION_DOWN,80,200);touch(v,MotionEvent.ACTION_MOVE,150,240);touch(v,MotionEvent.ACTION_UP,180,260);}
 @Test public void moveIsDefaultAndOneFingerPanDoesNotDraw(){EditorView v=view();assertEquals("Move",v.tool);List<EditDocument.Op> committed=new ArrayList<>();v.commit=committed::add;float before=v.centerX;touch(v,MotionEvent.ACTION_DOWN,100,200);touch(v,MotionEvent.ACTION_MOVE,160,200);touch(v,MotionEvent.ACTION_UP,160,200);assertTrue(v.centerX<before);assertTrue(committed.isEmpty());assertTrue(v.pendingStrokes.isEmpty());assertFalse(v.selected);}
 @Test public void drawingStaysPreviewUntilApplyAndCancelDiscardsIt(){for(String tool:new String[]{"Pen","Line","Arrow","Rectangle","Marker"}){EditorView v=view();List<EditDocument.Op> committed=new ArrayList<>();v.commit=committed::add;v.choose(tool);stroke(v);assertTrue(tool,committed.isEmpty());assertEquals(1,v.pendingStrokes.size());assertTrue(v.selected);v.clear();assertFalse(v.selected);assertTrue(v.pendingStrokes.isEmpty());assertTrue(committed.isEmpty());v.choose(tool);stroke(v);v.apply();assertEquals(1,committed.size());assertEquals(tool,committed.get(0).type);}}
 @Test public void multipleStrokesCanBeUndoneBeforeApplying(){EditorView v=view();List<EditDocument.Op> committed=new ArrayList<>();v.commit=committed::add;v.choose("Pen");stroke(v);stroke(v);assertEquals(2,v.pendingStrokes.size());assertTrue(v.undoPreview());assertEquals(1,v.pendingStrokes.size());v.apply();assertEquals(1,committed.size());assertTrue(v.undoPreview());assertFalse(v.selected);assertFalse(v.undoPreview());}
 @Test public void activityShowsApplyCancelAndReturnsToMoveAfterApply() throws Exception {try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).setup()){MainActivity a=c.get();new FloatingLayoutTest().load(a);new FloatingLayoutTest().layout(a,411,891);a.choose("Pen");int original=a.document.cursor;stroke(a.editor);assertEquals(original,a.document.cursor);assertEquals(View.VISIBLE,a.selectionActions.getVisibility());assertTrue(a.apply.isEnabled());assertTrue(a.cancel.isEnabled());a.apply.performClick();new EditableTextTest().finish(a);assertEquals(original+1,a.document.cursor);assertEquals("Move",a.editor.tool);assertEquals(View.GONE,a.selectionActions.getVisibility());assertTrue(a.editor.pendingStrokes.isEmpty());}}
 @Test public void activeToolTogglesOffAndHandAndCancelStopDrawing(){try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).setup()){MainActivity a=c.get();new FloatingLayoutTest().load(a);new FloatingLayoutTest().layout(a,411,891);a.choose("Pen");a.tools.get("Pen").performClick();assertEquals("Move",a.editor.tool);a.choose("Arrow");stroke(a.editor);assertTrue(a.editor.selected);a.cancel.performClick();assertEquals("Move",a.editor.tool);assertTrue(a.editor.pendingStrokes.isEmpty());a.choose("Pen");a.moveButton.performClick();assertEquals("Move",a.editor.tool);}}
}
