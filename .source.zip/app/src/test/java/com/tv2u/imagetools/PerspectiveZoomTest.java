package com.tv2u.imagetools;
import android.graphics.*;
import android.view.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=29,manifest=Config.NONE)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class PerspectiveZoomTest {
 EditorView view(){EditorView v=new EditorView(RuntimeEnvironment.getApplication());Bitmap b=Bitmap.createBitmap(400,240,Bitmap.Config.ARGB_8888);b.eraseColor(Color.CYAN);v.show(b);v.layout(0,0,300,600);v.choose("Perspective");v.updateViewport();return v;}
 @Test public void perspectiveStartsWithAllCornersVisibleAndCanZoomBelowCover(){EditorView v=view();assertTrue(v.zoom<1);assertEquals(v.minimumZoom(),v.zoom,.001);float[] points=v.quad.clone();v.imageToView.mapPoints(points);for(int i=0;i<8;i+=2){assertTrue(points[i]>=0&&points[i]<=300);assertTrue(points[i+1]>=0&&points[i+1]<=600);}float[] original=v.quad.clone();v.changeZoom(2);float enlarged=v.zoom;v.changeZoom(.8f);assertTrue(v.zoom<enlarged);v.fitImage();assertEquals(v.minimumZoom(),v.zoom,.001);assertEquals(150,v.display.centerX(),.01);assertEquals(300,v.display.centerY(),.01);assertArrayEquals(original,v.quad,0);assertTrue(v.selected);}
 @Test public void twoFingerPinchZoomsBothDirectionsWithoutMovingCorners(){EditorView v=view();v.zoom=1;v.updateViewport();float[] original=v.quad.clone();ViewportTest events=new ViewportTest();MotionEvent down=MotionEvent.obtain(0,0,MotionEvent.ACTION_DOWN,80,200,0);v.onTouchEvent(down);down.recycle();events.multi(v,MotionEvent.ACTION_POINTER_DOWN|(1<<MotionEvent.ACTION_POINTER_INDEX_SHIFT),80,200,220,200);events.multi(v,MotionEvent.ACTION_MOVE,120,220,180,220);assertTrue(v.zoom<1);float small=v.zoom;events.multi(v,MotionEvent.ACTION_MOVE,60,240,240,240);assertTrue(v.zoom>small);assertArrayEquals(original,v.quad,0);MotionEvent up=MotionEvent.obtain(0,40,MotionEvent.ACTION_UP,60,240,0);v.onTouchEvent(up);up.recycle();assertFalse(v.navigating);assertTrue(v.selected);}
 void touch(EditorView v,int action,float x,float y){float[] point={x,y};v.imageToView.mapPoints(point);MotionEvent e=MotionEvent.obtain(0,0,action,point[0],point[1],0);v.onTouchEvent(e);e.recycle();}
 @Test public void cornerDragAfterZoomAndPanUsesCorrectImageCoordinates(){EditorView v=view();v.zoom=2;v.centerX=v.quad[0];v.centerY=v.quad[1];v.updateViewport();float[] original=v.quad.clone();touch(v,MotionEvent.ACTION_DOWN,original[0],original[1]);touch(v,MotionEvent.ACTION_MOVE,original[0]+10,original[1]+8);touch(v,MotionEvent.ACTION_UP,original[0]+10,original[1]+8);assertEquals(original[0]+10,v.quad[0],.01);assertEquals(original[1]+8,v.quad[1],.01);for(int i=2;i<8;i++)assertEquals(original[i],v.quad[i],0);}
 @Test public void explicitZoomButtonsWorkAndDrawingReturnsToNoGap(){try(ActivityController<MainActivity> c=Robolectric.buildActivity(MainActivity.class).setup()){MainActivity a=c.get();new FloatingLayoutTest().load(a);new FloatingLayoutTest().layout(a,411,891);a.choose("Perspective");assertEquals(View.VISIBLE,a.zoomControls.getVisibility());float[] original=a.editor.quad.clone();a.zoomIn.performClick();float big=a.editor.zoom;a.zoomOut.performClick();assertTrue(a.editor.zoom<big);a.zoomFit.performClick();assertEquals(a.editor.minimumZoom(),a.editor.zoom,.001);assertArrayEquals(original,a.editor.quad,0);int cursor=a.document.cursor;a.setBusy(true);a.zoomIn.performClick();assertEquals(a.editor.minimumZoom(),a.editor.zoom,.001);a.setBusy(false);a.choose("Pen");a.editor.updateViewport();assertEquals(View.GONE,a.zoomControls.getVisibility());assertTrue(a.editor.zoom>=1);assertTrue(a.editor.display.top<=0&&a.editor.display.bottom>=a.editor.getHeight());assertEquals(cursor,a.document.cursor);}}
}
