package com.tv2u.imagetools;
import android.graphics.*;
import android.view.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=29,manifest=Config.NONE)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class ToolbarTest {
 @Test public void activityStartsWithNineDrawingToolsAndArrowCanBeSelected(){try(ActivityController<MainActivity> controller=Robolectric.buildActivity(MainActivity.class).setup()){
  MainActivity a=controller.get();assertEquals(9,a.tools.size());assertNotNull(a.tools.get("Arrow"));assertFalse(a.tools.get("Arrow").isEnabled());
  Bitmap b=Bitmap.createBitmap(200,100,Bitmap.Config.ARGB_8888);b.eraseColor(Color.WHITE);a.document=new EditDocument(b);a.editor.show(a.document.render());a.tools.get("Arrow").performClick();assertEquals("Arrow",a.editor.tool);assertTrue(a.tools.get("Arrow").isEnabled());assertEquals(View.VISIBLE,a.colorButton.getVisibility());
 }}
 @Test public void busyStateDisablesArrowAndCropPreviewShowsApply(){try(ActivityController<MainActivity> controller=Robolectric.buildActivity(MainActivity.class).setup()){
  MainActivity a=controller.get();Bitmap b=Bitmap.createBitmap(200,100,Bitmap.Config.ARGB_8888);a.document=new EditDocument(b);a.editor.show(a.document.render());a.choose("Crop");assertEquals(View.VISIBLE,a.selectionActions.getVisibility());assertTrue(a.apply.isEnabled());a.setBusy(true);assertFalse(a.tools.get("Arrow").isEnabled());assertFalse(a.apply.isEnabled());a.setBusy(false);assertTrue(a.apply.isEnabled());
 }}
}
