package com.tv2u.imagetools;
import android.graphics.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=29,manifest=Config.NONE)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class EditDocumentTest {
 Bitmap checker(){Bitmap b=Bitmap.createBitmap(96,64,Bitmap.Config.ARGB_8888);for(int y=0;y<64;y++)for(int x=0;x<96;x++)b.setPixel(x,y,(x%4<2)?Color.BLACK:Color.WHITE);return b;}
 @Test public void blurChangesOnlySelectionAndUnblurRestoresIt(){
  Bitmap original=checker();EditDocument d=new EditDocument(original);Rect r=new Rect(8,8,80,56);
  EditDocument blurred=d.add(EditDocument.Op.region("Blur",r));Bitmap image=blurred.render();
  assertEquals(original.getPixel(2,2),image.getPixel(2,2));assertNotEquals(original.getPixel(40,20),image.getPixel(40,20));
  Bitmap restored=blurred.add(EditDocument.Op.region("Unblur",new Rect(32,16,48,32))).render();assertEquals(original.getPixel(40,20),restored.getPixel(40,20));assertNotEquals(original.getPixel(20,20),restored.getPixel(20,20));
 }
 @Test public void textProducesVisiblePixelsAndUndoRedoRestoresThem(){
  Bitmap b=Bitmap.createBitmap(200,100,Bitmap.Config.ARGB_8888);b.eraseColor(Color.WHITE);EditDocument d=new EditDocument(b).add(EditDocument.Op.text("Hello",10,55,32,Color.BLACK));
  Bitmap edited=d.render();int dark=0;for(int y=0;y<100;y++)for(int x=0;x<200;x++)if(Color.red(edited.getPixel(x,y))<100)dark++;assertTrue("text should be visible",dark>20);
  Bitmap undone=d.undo().render();assertEquals(Color.WHITE,undone.getPixel(15,40));assertTrue(d.redo().render().sameAs(edited));assertTrue(d.undo().redo().render().sameAs(edited));
 }
 @Test public void cropAndRotationUseCorrectDimensionsAndKeepHistory(){
  EditDocument d=new EditDocument(checker());EditDocument crop=d.add(EditDocument.Op.region("Crop",new Rect(4,8,44,32)));Bitmap image=crop.render();assertEquals(40,image.getWidth());assertEquals(24,image.getHeight());
  Bitmap rotated=crop.add(EditDocument.Op.rotate(90)).render();assertEquals(24,rotated.getWidth());assertEquals(40,rotated.getHeight());assertEquals(96,crop.undo().render().getWidth());
 }
 @Test public void blurAndUnblurKeepPenAnnotation(){
  Path path=new Path();path.moveTo(10,20);path.lineTo(70,20);EditDocument d=new EditDocument(checker()).add(EditDocument.Op.pen(path,6,Color.RED)).add(EditDocument.Op.region("Blur",new Rect(0,0,96,64))).add(EditDocument.Op.region("Unblur",new Rect(0,0,96,64)));assertEquals(Color.RED,d.render().getPixel(30,20));
 }
 @Test public void newEditAfterUndoDropsRedoWithoutChangingPriorDocument(){
  EditDocument first=new EditDocument(checker()).add(EditDocument.Op.rotate(90));EditDocument second=first.undo().add(EditDocument.Op.region("Crop",new Rect(0,0,20,20)));assertEquals(1,first.ops.size());assertEquals(1,first.cursor);assertEquals(second.cursor,second.ops.size());assertEquals(20,second.render().getWidth());
 }
 @Test public void masksRemainDrawableAfterCropAndRotate(){
  EditDocument d=new EditDocument(checker()).add(EditDocument.Op.region("Crop",new Rect(2,2,90,60))).add(EditDocument.Op.rotate(90)).add(EditDocument.Op.region("Blur",new Rect(0,0,20,20))).add(EditDocument.Op.region("Unblur",new Rect(0,0,5,5)));assertNotNull(d.render());
 }
}
