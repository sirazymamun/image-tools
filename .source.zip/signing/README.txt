This is a public DEVELOPMENT key for easy personal APK builds. It is intentionally
included so builds on different computers keep the same signature and can update.
Password: android; alias: androiddebugkey; key password: android.
Do not use this public key for a production / Play Store release.
For a private production key, supply the optional GitHub Secrets in the tutorial.
Keep that private key for all future updates. Switching signing keys requires
uninstalling the old APK before installing a build signed with the new key.
